# Reproducibility Specification
## Explainable Hybrid ViT-CNN with Cross-Attention Fusion for Breast Cancer Receptor Status Prediction

---

## 1. Datasets

### 1.1 Primary Dataset — BINO Hospital
- **Source:** Bahawalpur Institute of Nuclear Medicine and Oncology (BINO), Bahawalpur, Pakistan
- **Period:** January 2020 – December 2024
- **WSIs:** 8,247 from 5,632 patients
- **Modality:** H&E stained Whole Slide Images
- **Scanner:** [NOT STATED IN PAPER] — default: Aperio AT2
- **Receptor distribution:** ER+ 72.4% (of IHC-confirmed), HER2-enriched 18.3%, TNBC 17.5%, HR+ 64.2%
- **Histologic subtype:** IDC 72.4%, ILC 18.6%, Special 9.0%
- **IHC ground truth:** ER, PR, HER2 (ASCO/CAP 2018 guidelines)
- **Availability:** PROPRIETARY — not publicly available. Contact: BINO Hospital, Bahawalpur, Pakistan
- **Split:** Patient-level 70/15/15
  - Train: 3,942 patients / 5,773 WSIs
  - Val: 845 patients / 1,237 WSIs
  - Test: 845 patients / 1,237 WSIs

### 1.2 External Validation Cohorts
- **SKMH (Shaukat Khanum Memorial Cancer Hospital):** 981 WSIs
- **AKUH (Aga Khan University Hospital):** 847 WSIs
- **NIH Islamabad:** 1,019 WSIs
- **Total external:** 2,847 WSIs
- **Availability:** PROPRIETARY — multi-institutional data sharing agreements required

### 1.3 Public Benchmarks
- **TCGA-BRCA**
  - Source: https://portal.gdc.cancer.gov/projects/TCGA-BRCA
  - Version: GDC Data Release 38.0
  - License: dbGaP (open-access tier for open-access files)
  - WSIs: 1,047
  - Used for: External generalizability (Table 10)
- **BreaKHis**
  - Source: https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/
  - DOI: 10.1109/TBME.2015.2505512
  - License: CC BY 4.0
  - Patches: 7,909
  - Used for: Patch-level benchmark (Table 10)

---

## 2. Model Architecture

### 2.1 ViT Branch (PLIP-ViT-Base)
- **Backbone:** Vision Transformer Base, pretrained via PLIP
- **PLIP pretraining:** ~208,000 histopathology image-text pairs (OpenPath dataset + medical Twitter)
- **Pretrained weights:** https://huggingface.co/vinid/plip [VERIFY BEFORE USE]
- **Layers:** 12 transformer blocks
- **Attention heads:** 12 per block
- **Hidden dimension:** 768
- **Patch size:** 16×16 (within 224×224 input → 196 patches + 1 CLS)
- **Freezing:** First 6 blocks frozen; last 6 trainable at lr=5×10⁻⁶
- **Dropout:** 0.10
- **Output:** CLS token → 768-dim feature F_vit_cls; patch tokens N_v=196

### 2.2 CNN Branch (ResNet-50)
- **Backbone:** ResNet-50, ImageNet pretrained
- **Modifications:**
  - Spatial attention gates at each residual stage
  - Dilated convolutions in stages 3 and 4 (dilation rates [NOT STATED IN PAPER] — default: 2, 4)
- **Fine-tuning:** All layers trainable at lr=2×10⁻⁵
- **Dropout:** 0.15
- **Output:** Global average pooled feature F_cnn_pool → 2048→1024 via projection; spatial tokens N_c=49

### 2.3 Dynamic Scale-Switching Module (DSSM)
- **Nucleus density (ND) threshold:** 0.62
- **ND > 0.62:** Dense cellular region → patches extracted at 224×224
- **ND ≤ 0.62:** Architectural region → patches extracted at 1024×1024, then resized to 224×224
- **Stride:** 50% overlap
- **Tissue segmentation:** Otsu thresholding on grayscale thumbnail [NOT STATED — default]

### 2.4 Macenko Colour Normalisation
- **Reference stain matrix:** [NOT STATED IN PAPER] — default: standard TCGA reference
- **Method:** Macenko et al. (2009) SVD-based stain separation
- **Applied:** Before patch extraction

### 2.5 Bidirectional Cross-Attention Fusion
- **Heads:** 8
- **Head dimension:** 128 (total d_model = 1,024)
- **Query/Key/Value source (ViT→CNN direction):** Q=F_cnn, K=F_vit_tokens, V=F_vit_tokens
- **Query/Key/Value source (CNN→ViT direction):** Q=F_vit, K=F_cnn_tokens, V=F_cnn_tokens
- **ViT tokens:** N_v = 196 (patch tokens from last ViT block)
- **CNN tokens:** N_c = 49 (7×7 spatial grid from ResNet layer4)
- **Cross-attention output:** 1,024-dim
- **Fusion concatenation:** [F_vit_cls (768); F_cnn_pool (1024); F_cross (1024)] → 2816-dim
  - Note: Paper states "3072→1024 via W_fusion" — see Section 3.5 note below
- **Fusion head:** Linear(2816 or 3072, 1024), LayerNorm, GELU, Dropout(0.20)

### 2.6 Classification Heads
- **Receptor heads (×3):** Linear(1024, 1) + Sigmoid for ER, PR, HER2
- **Subtype head:** Linear(1024, 4) + Softmax for {Luminal A, Luminal B, HER2-enriched, TNBC}

### 2.7 MC Dropout (Uncertainty Estimation)
- **Inference passes:** T = 30
- **Confidence threshold:** 0.85
- **Uncertainty metric:** Predictive variance across 30 forward passes

---

## 3. Hyperparameters

| Parameter | Value |
|-----------|-------|
| Optimizer | Adam |
| Global LR | 2×10⁻⁵ |
| PLIP trainable layers LR | 5×10⁻⁶ |
| β₁ | 0.9 |
| β₂ | 0.999 |
| ε | 1×10⁻⁸ |
| Weight decay | 1×10⁻⁴ |
| Batch size | 32 |
| Max epochs | 100 |
| Early stopping patience | 15 epochs |
| LR scheduler | CosineAnnealingLR |
| T_max | 50 |
| η_min | 1×10⁻⁷ |
| Gradient clip norm | 1.0 |
| Random seed | 42 |
| Mixed precision | FP16 (PyTorch AMP) |
| Input resolution | 224×224 |
| ViT dropout | 0.10 |
| CNN dropout | 0.15 |
| Fusion/head dropout | 0.20 |
| Warmup | [NOT STATED IN PAPER] — default: 5 epochs linear |

### 3.1 Loss Function
```
L_focal(y, p) = -α_t · (1 − p_t)^γ · log(p_t)
  where p_t = p if y=1 else (1−p)
        α_t = α if y=1 else (1−α)
γ = 2.0  [NOT STATED — default focal gamma]
α = 0.25 [NOT STATED — default focal alpha]

L_total = 0.40 · L_ER + 0.30 · L_PR + 0.30 · L_HER2
L_final = L_total + 0.20 · L_subtype
```

### 3.2 Augmentations
- [NOT STATED IN PAPER] — defaults used:
  - Random horizontal flip (p=0.5)
  - Random vertical flip (p=0.5)
  - Random rotation ±90°
  - Color jitter: brightness=0.2, contrast=0.2, saturation=0.1, hue=0.05
  - Normalization: mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225] (ImageNet)

---

## 4. Hardware and Software

| Item | Specification |
|------|---------------|
| GPU | NVIDIA A100 40GB |
| Framework | PyTorch 2.1.0 |
| CUDA | [NOT STATED] — default: 12.1 |
| cuDNN | [NOT STATED] — default: 8.9 |
| Python | [NOT STATED] — default: 3.10 |

---

## 5. Evaluation Metrics

| Metric | Formula | Averaging |
|--------|---------|-----------|
| AUROC | Trapezoidal rule, DeLong's method | Per-class |
| Accuracy | (TP+TN)/(TP+TN+FP+FN) | Macro |
| Sensitivity (Recall) | TP/(TP+FN) | Per-class |
| Specificity | TN/(TN+FP) | Per-class |
| PPV (Precision) | TP/(TP+FP) | Per-class |
| NPV | TN/(TN+FN) | Per-class |
| F1 | 2·PPV·Sensitivity/(PPV+Sensitivity) | Macro |
| MCC | (TP·TN−FP·FN)/√((TP+FP)(TP+FN)(TN+FP)(TN+FN)) | Per-class |
| Brier Score | (1/N)Σ(pᵢ−yᵢ)² | Per-class |
| ECE | Σ(|Bₘ|/N)·\|acc(Bₘ)−conf(Bₘ)\| | Per-class, 10 bins |
| MCE | max_m \|acc(Bₘ)−conf(Bₘ)\| | Per-class |

Results reported as mean ± std across 5 seeds.

---

## 6. Baselines and Ablation Variants

### 6.1 Architecture Ablations (Table 6)
1. CNN-only (ResNet-50, no ViT, no cross-attention)
2. ViT-only (PLIP-ViT-Base, no CNN, no cross-attention)
3. ViT+CNN concatenation (no cross-attention fusion)
4. Fixed patch 224×224 (no DSSM, always 224×224)
5. Fixed patch 1024×1024 (no DSSM, always 1024×1024)
6. **Proposed** (full model)

### 6.2 Fusion Ablations (Table 7)
1. Concatenation + MLP
2. Additive fusion
3. Gated fusion
4. FiLM conditioning
5. Multi-stage progressive fusion
6. **Cross-attention (proposed)**

### 6.3 SOTA Baselines (Table 5)
1. DCS-ST (Li et al., 2023) — IEEE IoT J
2. TokenMixer-Net (Chen et al., 2023) — IEEE Trans Med Imaging
3. (Additional baselines as cited in paper)

### 6.4 PLIP Pretraining Ablation (Table 1)
1. From scratch
2. ImageNet pretrained
3. PLIP pretrained (proposed)

---

## 7. Target Numeric Tables

### Table 1 — PLIP Pretraining Ablation
| Strategy | Mean AUC | Epochs | Training Time (h) |
|----------|---------|--------|-------------------|
| From scratch | 0.891 | 87 | 31.4 |
| ImageNet-pretrained | 0.931 | 64 | 23.1 |
| PLIP-pretrained (proposed) | 0.953 | 52 | 18.9 |

### Table 3 — Individual Receptor Performance
| Receptor | AUC | Accuracy | Sensitivity | Specificity | PPV | NPV |
|----------|-----|---------|------------|------------|-----|-----|
| ER | 0.967±0.012 | 94.8±1.3% | 96.2±1.1% | 92.4±1.7% | 95.7±1.2% | 93.8±1.5% |
| PR | 0.952±0.015 | 92.6±1.8% | 94.1±1.4% | 90.8±2.1% | 93.3±1.6% | 91.9±1.8% |
| HER2 | 0.941±0.018 | 91.3±2.1% | 92.7±1.9% | 89.6±2.4% | 90.8±2.0% | 91.8±1.7% |

### Table 4 — Molecular Subtype
| Subtype | Precision | Recall | F1 | Support | Accuracy |
|---------|-----------|--------|-----|---------|---------|
| Luminal A | 97.2% | 95.8% | 96.5% | 794 | 96.8% |
| Luminal B | 94.6% | 93.2% | 93.9% | 321 | 94.1% |
| HER2-enriched | 95.8% | 94.7% | 95.2% | 226 | 95.3% |
| TNBC | 97.9% | 96.4% | 97.1% | 216 | 97.2% |
| Overall | 96.8% | 95.4% | 96.1% | 1557 | 96.8% |

### Table 6 — Architecture Ablation
| Variant | ER AUC | PR AUC | HER2 AUC | Accuracy | F1 | Inference (s/WSI) |
|---------|--------|--------|---------|---------|-----|-------------------|
| CNN-only | 0.914 | 0.901 | 0.888 | 87.6% | 86.9% | 3.9 |
| ViT-only | 0.926 | 0.912 | 0.901 | 90.2% | 89.7% | 3.7 |
| ViT+CNN (no fusion) | 0.938 | 0.928 | 0.914 | 92.4% | 91.6% | 3.1 |
| Fixed 224×224 | 0.941 | 0.928 | 0.916 | 90.8% | 89.9% | 2.1 |
| Fixed 1024×1024 | 0.948 | 0.933 | 0.921 | 91.6% | 90.7% | 4.7 |
| Proposed | 0.967 | 0.952 | 0.941 | 96.8% | 95.5% | 2.3 |

### Table 7 — Fusion Comparison
| Fusion Method | ER AUC | PR AUC | HER2 AUC | Accuracy | Inference (s/WSI) |
|---------------|--------|--------|---------|---------|-------------------|
| Concatenation+MLP | 0.934 | 0.921 | 0.908 | 91.3% | 2.8 |
| Additive | 0.929 | 0.915 | 0.901 | 90.6% | 2.5 |
| Gated | 0.942 | 0.931 | 0.917 | 92.7% | 2.9 |
| FiLM | 0.938 | 0.924 | 0.912 | 91.8% | 3.1 |
| Multi-stage | 0.951 | 0.939 | 0.926 | 93.4% | 3.6 |
| Cross-attention (proposed) | 0.967 | 0.952 | 0.941 | 96.8% | 2.3 |

### Table 8 — Multi-Institutional Validation
| Institution | N WSIs | ER AUC | PR AUC | HER2 AUC |
|-------------|--------|--------|--------|---------|
| BINO (internal test) | 1,237 | 0.967±0.012 | 0.952±0.015 | 0.941±0.018 |
| SKMH | 981 | 0.954±0.019 | 0.943±0.022 | 0.929±0.025 |
| AKUH | 847 | 0.961±0.016 | 0.948±0.019 | 0.935±0.021 |
| NIH Islamabad | 1,019 | 0.958±0.017 | 0.945±0.020 | 0.932±0.023 |
| Combined External | 2,847 | 0.958±0.017 | 0.945±0.020 | 0.932±0.023 |

### Table 9 — Leave-One-Institution-Out
| Held Out | ER AUC | PR AUC | HER2 AUC | Accuracy |
|----------|--------|--------|---------|---------|
| BINO | 0.956±0.021 | 0.943±0.024 | 0.929±0.027 | 95.4±1.8% |
| SKMH | 0.961±0.018 | 0.947±0.021 | 0.933±0.024 | 96.1±1.5% |
| AKUH | 0.958±0.019 | 0.944±0.022 | 0.931±0.025 | 95.7±1.6% |
| NIH | 0.963±0.017 | 0.949±0.020 | 0.935±0.023 | 96.4±1.4% |
| Mean | 0.960±0.003 | 0.946±0.003 | 0.932±0.003 | 95.9±0.4% |

### Table 10 — Public Benchmark
| Dataset | N | ER AUC | PR AUC | HER2 AUC | Accuracy |
|---------|---|--------|--------|---------|---------|
| TCGA-BRCA | 1,047 | 0.951±0.019 | 0.937±0.022 | 0.924±0.025 | 94.3±1.7% |
| BreaKHis | 7,909 patches | — | — | — | 93.7±1.4% |

### Table 11 — Computational Performance
| Phase | Time (s/WSI) | GPU Memory (GB) | Throughput (WSI/h) |
|-------|-------------|----------------|-------------------|
| Training | 45.2±3.8 | 38.2±2.1 | 79.5±5.2 |
| Validation | 12.7±1.9 | 15.4±1.2 | 283.6±15.4 |
| Inference | 2.3±0.4 | 8.7±0.8 | 1565.2±87.3 |
| Parameters | 127.4M | (ViT: 86.6M, CNN: 25.4M, Fusion: 15.4M) | |
| FLOPs | 2.84×10¹¹ | | |

### Table 14 — Calibration Metrics
| Receptor | Brier Score | ECE | MCE |
|----------|------------|-----|-----|
| ER | 0.043±0.005 | 2.1±0.3% | 4.7±0.6% |
| PR | 0.057±0.006 | 2.8±0.4% | 5.9±0.7% |
| HER2 | 0.068±0.008 | 3.4±0.5% | 7.1±0.9% |
