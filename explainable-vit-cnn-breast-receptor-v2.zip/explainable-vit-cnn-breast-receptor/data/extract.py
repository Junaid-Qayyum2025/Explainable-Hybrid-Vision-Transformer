"""
Extract and organise downloaded dataset archives.

Usage:
    python data/extract.py --dataset breakhis --archive data/raw/BreaKHis_v1.tar.gz --out_dir data/raw/breakhis
    python data/extract.py --dataset tcga_brca --in_dir data/raw/tcga_brca --out_dir data/raw/tcga_brca_organised
"""
import argparse
import csv
import os
import re
import tarfile
import zipfile
from pathlib import Path
from typing import Dict, List


# ---------------------------------------------------------------------------
# BreaKHis
# ---------------------------------------------------------------------------
def extract_breakhis(archive_path: str, out_dir: str) -> None:
    """
    Extract BreaKHis v1 archive and organise into class folders.

    BreaKHis structure inside archive:
      BreaKHis_v1/histology_slides/breast/
        benign/SOB/<subtype>/<slide_id>/<magnification>/*.png
        malignant/SOB/<subtype>/<slide_id>/<magnification>/*.png

    We flatten to: {out_dir}/{benign|malignant}/{slide_id}/*.png
    """
    print(f"Extracting BreaKHis archive: {archive_path}")
    os.makedirs(out_dir, exist_ok=True)

    with tarfile.open(archive_path, "r:gz") as tar:
        members = tar.getmembers()
        print(f"  {len(members)} files in archive")
        tar.extractall(out_dir)

    print(f"  Extracted to: {out_dir}")
    print("  Organising files...")

    # Build a flat manifest CSV for downstream use
    manifest_path = os.path.join(out_dir, "breakhis_manifest.csv")
    rows = []
    base = Path(out_dir)

    for png in base.rglob("*.png"):
        rel = png.relative_to(base)
        parts = rel.parts
        # Path: BreaKHis_v1/histology_slides/breast/{benign|malignant}/SOB/{subtype}/{slide_id}/{mag}/*.png
        if len(parts) >= 7:
            label = parts[3]          # benign or malignant
            subtype = parts[5]
            slide_id = parts[6]
            magnification = parts[7]
        else:
            label = "unknown"
            subtype = "unknown"
            slide_id = png.stem
            magnification = "unknown"

        rows.append({
            "filepath": str(png),
            "label": label,
            "subtype": subtype,
            "slide_id": slide_id,
            "magnification": magnification,
        })

    with open(manifest_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["filepath", "label", "subtype", "slide_id", "magnification"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"  Manifest written: {manifest_path} ({len(rows)} patches)")


# ---------------------------------------------------------------------------
# TCGA-BRCA
# ---------------------------------------------------------------------------
def organise_tcga_brca(in_dir: str, out_dir: str, clinical_tsv: str = "") -> None:
    """
    Organise downloaded TCGA-BRCA SVS files.

    Files downloaded by gdc-client are placed in UUIDs subdirectories.
    We create a manifest CSV mapping slide UUID → case_id → receptor status.

    Clinical data (with ER/PR/HER2 status) must be downloaded separately:
      https://portal.gdc.cancer.gov/projects/TCGA-BRCA → Clinical > Download
    """
    os.makedirs(out_dir, exist_ok=True)

    # Find all SVS files
    svs_files = list(Path(in_dir).rglob("*.svs"))
    print(f"Found {len(svs_files)} SVS files in {in_dir}")

    manifest_path = os.path.join(out_dir, "tcga_brca_slides.csv")
    rows = []
    for svs in svs_files:
        # GDC file UUID is the parent directory name
        uuid = svs.parent.name
        case_id = re.match(r"(TCGA-[A-Z0-9]{2}-[A-Z0-9]{4})", svs.name)
        case_id = case_id.group(1) if case_id else "UNKNOWN"
        rows.append({
            "slide_id": svs.stem,
            "filepath": str(svs),
            "uuid": uuid,
            "case_id": case_id,
            "er_status": "",    # To be filled from clinical data
            "pr_status": "",
            "her2_status": "",
            "subtype": "",
        })

    with open(manifest_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else [])
        writer.writeheader()
        writer.writerows(rows)

    print(f"Slide manifest: {manifest_path}")

    if clinical_tsv and os.path.exists(clinical_tsv):
        _merge_tcga_clinical(manifest_path, clinical_tsv)
    else:
        print()
        print("IMPORTANT: To add receptor labels, download clinical data:")
        print("  1. Go to https://portal.gdc.cancer.gov/projects/TCGA-BRCA")
        print("  2. Clinical > Download")
        print("  3. Re-run with --clinical_tsv <path>")
        print()
        print("Alternatively, use the TCGAbiolinks R package:")
        print("  TCGAbiolinks::GDCquery_clinic('TCGA-BRCA', 'clinical')")


def _merge_tcga_clinical(manifest_path: str, clinical_tsv: str) -> None:
    """Merge clinical receptor labels into the slide manifest."""
    import pandas as pd

    slides = pd.read_csv(manifest_path)
    clinical = pd.read_csv(clinical_tsv, sep="\t", low_memory=False)

    # Standard TCGA clinical column names
    er_col = next((c for c in clinical.columns if "er_status" in c.lower()), None)
    pr_col = next((c for c in clinical.columns if "pr_status" in c.lower()), None)
    her2_col = next((c for c in clinical.columns if "her2_status" in c.lower()), None)
    case_col = next((c for c in clinical.columns if "case_id" in c.lower()), None)

    if not all([er_col, pr_col, her2_col, case_col]):
        print(f"WARNING: Could not find receptor columns in {clinical_tsv}")
        print(f"  Available columns: {list(clinical.columns)[:20]}")
        return

    clinical_small = clinical[[case_col, er_col, pr_col, her2_col]].rename(columns={
        case_col: "case_id", er_col: "er_status", pr_col: "pr_status", her2_col: "her2_status"
    })
    merged = slides.merge(clinical_small, on="case_id", how="left", suffixes=("_old", ""))
    for col in ["er_status", "pr_status", "her2_status"]:
        if f"{col}_old" in merged.columns:
            merged.drop(columns=[f"{col}_old"], inplace=True)
    merged.to_csv(manifest_path, index=False)
    labelled = merged[merged["er_status"].notna()].shape[0]
    print(f"  Clinical merge: {labelled}/{len(merged)} slides labelled")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Extract and organise dataset archives.")
    parser.add_argument("--dataset", choices=["breakhis", "tcga_brca"], required=True)
    parser.add_argument("--archive", default=None, help="Path to .tar.gz or .zip archive (breakhis)")
    parser.add_argument("--in_dir", default=None, help="Input directory (tcga_brca)")
    parser.add_argument("--out_dir", required=True, help="Output directory")
    parser.add_argument("--clinical_tsv", default="", help="TCGA clinical TSV for label merging")
    args = parser.parse_args()

    if args.dataset == "breakhis":
        if not args.archive:
            parser.error("--archive required for breakhis")
        extract_breakhis(args.archive, args.out_dir)

    elif args.dataset == "tcga_brca":
        if not args.in_dir:
            parser.error("--in_dir required for tcga_brca")
        organise_tcga_brca(args.in_dir, args.out_dir, clinical_tsv=args.clinical_tsv)


if __name__ == "__main__":
    main()
