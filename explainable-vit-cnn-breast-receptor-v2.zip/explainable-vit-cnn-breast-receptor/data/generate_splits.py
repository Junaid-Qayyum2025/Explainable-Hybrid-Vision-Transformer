"""
Generate patient-level 70/15/15 splits for public datasets.

Usage:
    python data/generate_splits.py --dataset tcga_brca \
        --manifest data/raw/tcga_brca/tcga_brca_slides.csv \
        --out_dir data/splits --seed 42
"""
import argparse
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


def generate_splits(manifest_path: str, out_dir: str, seed: int = 42) -> None:
    df = pd.read_csv(manifest_path)

    # Map receptor status to binary labels
    for col, name in [("er_status", "er"), ("pr_status", "pr"), ("her2_status", "her2")]:
        if col in df.columns:
            df[f"{name}_label"] = df[col].map(
                lambda x: 1 if str(x).lower() in ("positive", "pos", "1") else 0
            )

    # Patient-level split: group all slides per patient
    if "case_id" in df.columns:
        patient_col = "case_id"
    elif "patient_id" in df.columns:
        patient_col = "patient_id"
    else:
        df["patient_id"] = df.index.astype(str)
        patient_col = "patient_id"

    patients = df[patient_col].unique()
    rng = np.random.default_rng(seed)

    # Stratify by ER status if available
    if "er_label" in df.columns:
        patient_df = df.groupby(patient_col)["er_label"].first().reset_index()
        stratify = patient_df["er_label"].values
    else:
        patient_df = pd.DataFrame({patient_col: patients})
        stratify = None

    train_patients, temp_patients = train_test_split(
        patient_df[patient_col].values, test_size=0.30, random_state=seed,
        stratify=stratify
    )
    if stratify is not None:
        temp_stratify = patient_df[patient_df[patient_col].isin(temp_patients)]["er_label"].values
    else:
        temp_stratify = None
    val_patients, test_patients = train_test_split(
        temp_patients, test_size=0.50, random_state=seed, stratify=temp_stratify
    )

    os.makedirs(out_dir, exist_ok=True)
    for split_name, split_patients in [("train", train_patients), ("val", val_patients), ("test", test_patients)]:
        split_df = df[df[patient_col].isin(split_patients)].copy()
        out_path = os.path.join(out_dir, f"tcga_brca_{split_name}.csv")
        split_df.to_csv(out_path, index=False)
        print(f"{split_name}: {len(split_patients)} patients, {len(split_df)} slides -> {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    generate_splits(args.manifest, args.out_dir, args.seed)


if __name__ == "__main__":
    main()
