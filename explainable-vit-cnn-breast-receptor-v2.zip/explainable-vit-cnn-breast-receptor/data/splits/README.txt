Patient-level split files
=========================
BINO split files are not distributed (proprietary data). Split sizes used in the paper:
  train: 3,942 patients / 5,773 WSIs; val: 845 / 1,237; test: 845 / 1,237 (patient-level, seed 42).
Public-data splits are generated with:
  python data/generate_splits.py --manifest data/raw/tcga_brca/tcga_brca_slides.csv --out_dir data/splits --seed 42
(stratified by ER status; produces tcga_brca_{train,val,test}.csv)
