"""
Preprocessing pipeline for H&E WSIs.

Steps (paper Section 3):
  1. Tissue segmentation (Otsu thresholding on grayscale thumbnail)
  2. Macenko colour normalisation
  3. DSSM nucleus density estimation
  4. Adaptive patch extraction at 224x224 (ND>0.62) or 1024x1024 (ND<=0.62)
  5. Resize all patches to 224x224

Usage:
    python data/preprocess.py --config configs/main_model.yaml \
        --wsi_dir data/raw/bino --out_dir data/processed --split train
"""
import argparse
import os
import sys
from pathlib import Path
from typing import List, Tuple, Optional

import cv2
import numpy as np
import yaml
from PIL import Image
from tqdm import tqdm

# Conditionally import OpenSlide (requires libopenslide)
try:
    import openslide
    OPENSLIDE_AVAILABLE = True
except ImportError:
    OPENSLIDE_AVAILABLE = False
    print("WARNING: openslide-python not available. WSI reading disabled.")


def load_config(config_path: str) -> dict:
    with open(config_path) as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Tissue segmentation
# ---------------------------------------------------------------------------
def segment_tissue(thumbnail: np.ndarray, threshold: int = 0) -> np.ndarray:
    """
    Binary tissue mask using Otsu thresholding on grayscale thumbnail.
    Returns mask of same spatial dimensions as thumbnail.
    """
    gray = cv2.cvtColor(thumbnail, cv2.COLOR_RGB2GRAY)
    _, mask = cv2.threshold(
        gray, threshold, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
    )
    # Morphological cleanup
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    return mask


# ---------------------------------------------------------------------------
# Nucleus density estimation (DSSM)
# ---------------------------------------------------------------------------
def estimate_nucleus_density(patch: np.ndarray) -> float:
    """
    Estimate nucleus density for a single RGB patch.
    Uses haematoxylin channel intensity as a proxy for nuclear density.

    Paper: ND threshold = 0.62
    ND > 0.62 → dense cellular → 224x224 patch
    ND <= 0.62 → architectural → 1024x1024 patch
    """
    # Convert to grayscale and apply Gaussian blur
    gray = cv2.cvtColor(patch, cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
    blurred = cv2.GaussianBlur(gray, (5, 5), 1.0)

    # Threshold to detect nuclei (dark-staining regions in H&E)
    _, nucleus_mask = cv2.threshold(
        (1.0 - blurred * 255).astype(np.uint8), 0, 255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    # Nucleus density = fraction of pixels classified as nuclei
    nd = float(nucleus_mask.sum()) / (255.0 * nucleus_mask.size)
    return nd


# ---------------------------------------------------------------------------
# Macenko colour normalisation
# ---------------------------------------------------------------------------
class MacenkoNormaliser:
    """
    Macenko et al. (2009) stain normalisation.
    Reference: DOI: 10.1109/ISBI.2009.5193250
    """

    def __init__(self, reference_path: Optional[str] = None, beta: float = 0.15, alpha: float = 1.0):
        self.beta = beta
        self.alpha = alpha
        self.HE_ref = None

        if reference_path and os.path.exists(reference_path):
            ref_img = np.array(Image.open(reference_path).convert("RGB"))
            self.HE_ref, _ = self._get_stain_matrix(ref_img)
        else:
            # Default reference stain matrix (from a representative TCGA slide)
            # [NOT STATED IN PAPER] — using standard Macenko reference values
            self.HE_ref = np.array([
                [0.5626, 0.2159],
                [0.7201, 0.8012],
                [0.4062, 0.5581]
            ])

    def _get_stain_matrix(self, img: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        img = img.astype(np.float64) + 1e-6
        img_od = -np.log(img / 255.0)
        img_od_flat = img_od.reshape(-1, 3)

        # Remove pixels below threshold
        mask = (img_od_flat > self.beta).any(axis=1)
        img_od_hat = img_od_flat[mask]

        # SVD
        _, _, V = np.linalg.svd(img_od_hat, full_matrices=False)
        plane = V[:2]

        # Project onto the 2D plane
        projected = img_od_hat @ plane.T

        # Find min/max directions
        angles = np.arctan2(projected[:, 1], projected[:, 0])
        phi_1 = np.percentile(angles, self.alpha)
        phi_2 = np.percentile(angles, 100 - self.alpha)

        v1 = np.array([np.cos(phi_1), np.sin(phi_1)])
        v2 = np.array([np.cos(phi_2), np.sin(phi_2)])

        stain_1 = (plane * v1[:, None]).sum(0)
        stain_2 = (plane * v2[:, None]).sum(0)

        if stain_1[0] < stain_2[0]:
            stain_1, stain_2 = stain_2, stain_1

        HE = np.stack([stain_1, stain_2], axis=1)
        HE /= (np.linalg.norm(HE, axis=0) + 1e-8)

        # Concentrations
        conc = np.linalg.lstsq(HE, img_od_flat.T, rcond=None)[0]
        return HE, conc

    def normalise(self, img: np.ndarray) -> np.ndarray:
        """Normalise a single RGB patch (H x W x 3, uint8)."""
        try:
            HE_src, conc = self._get_stain_matrix(img)
            max_conc = np.percentile(conc, 99, axis=1, keepdims=True)
            conc = conc / (max_conc + 1e-8)
            normalised_od = self.HE_ref @ conc
            normalised = 255.0 * np.exp(-normalised_od.T.reshape(img.shape))
            normalised = np.clip(normalised, 0, 255).astype(np.uint8)
            return normalised
        except np.linalg.LinAlgError:
            # Return original if normalisation fails
            return img


# ---------------------------------------------------------------------------
# Patch extraction
# ---------------------------------------------------------------------------
def extract_patches_from_wsi(
    wsi_path: str,
    out_dir: str,
    normaliser: MacenkoNormaliser,
    nucleus_density_threshold: float = 0.62,
    patch_size_dense: int = 224,
    patch_size_sparse: int = 1024,
    target_size: int = 224,
    stride_overlap: float = 0.5,
    level: int = 0,
) -> List[str]:
    """
    Extract patches from a WSI according to the DSSM strategy.

    Returns list of saved patch paths.
    """
    if not OPENSLIDE_AVAILABLE:
        raise RuntimeError("openslide-python required for WSI extraction.")

    slide = openslide.OpenSlide(wsi_path)
    slide_id = Path(wsi_path).stem
    patch_out_dir = Path(out_dir) / slide_id
    patch_out_dir.mkdir(parents=True, exist_ok=True)

    # Thumbnail for tissue segmentation
    thumb_size = (512, 512)
    thumbnail = np.array(slide.get_thumbnail(thumb_size).convert("RGB"))
    mask = segment_tissue(thumbnail)

    # Scale mask to slide dimensions
    w, h = slide.level_dimensions[level]
    scale_x = w / thumb_size[0]
    scale_y = h / thumb_size[1]

    saved_paths = []

    # Determine initial patch size (use dense as default scan grid)
    scan_size = patch_size_dense
    stride = int(scan_size * (1 - stride_overlap))

    for y in range(0, h - scan_size, stride):
        for x in range(0, w - scan_size, stride):
            # Check tissue coverage
            tx = int(x / scale_x)
            ty = int(y / scale_y)
            tw = max(1, int(scan_size / scale_x))
            th = max(1, int(scan_size / scale_y))
            region_mask = mask[ty:ty + th, tx:tx + tw]
            coverage = region_mask.mean() / 255.0
            if coverage < 0.5:
                continue

            # Read patch at dense scale for ND estimation
            patch_small = np.array(
                slide.read_region((x, y), level, (scan_size, scan_size)).convert("RGB")
            )
            nd = estimate_nucleus_density(patch_small)

            # DSSM: select patch scale based on nucleus density
            if nd > nucleus_density_threshold:
                patch_size = patch_size_dense
                patch_img = patch_small  # Already at 224x224
            else:
                patch_size = patch_size_sparse
                # Re-read at larger scale (if within slide bounds)
                if x + patch_size <= w and y + patch_size <= h:
                    patch_img = np.array(
                        slide.read_region((x, y), level, (patch_size, patch_size)).convert("RGB")
                    )
                else:
                    patch_img = patch_small

            # Macenko normalisation
            patch_norm = normaliser.normalise(patch_img)

            # Resize to target size (224x224)
            if patch_norm.shape[0] != target_size:
                patch_norm = np.array(
                    Image.fromarray(patch_norm).resize((target_size, target_size), Image.LANCZOS)
                )

            # Save patch
            fname = f"x{x}_y{y}_nd{nd:.3f}_sz{patch_size}.png"
            fpath = str(patch_out_dir / fname)
            Image.fromarray(patch_norm).save(fpath)
            saved_paths.append(fpath)

    slide.close()
    return saved_paths


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Preprocess WSIs: tissue segment, Macenko normalise, DSSM patch extract.")
    parser.add_argument("--config", required=True, help="Path to YAML config file")
    parser.add_argument("--wsi_dir", required=True, help="Directory containing WSI files (.svs, .ndpi, .tiff)")
    parser.add_argument("--out_dir", required=True, help="Output directory for extracted patches")
    parser.add_argument("--split_csv", default=None, help="CSV with slide IDs to process (optional)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    pp = cfg.get("preprocessing", {})
    dssm = cfg.get("dssm", {})

    normaliser = MacenkoNormaliser(
        reference_path=pp.get("reference_image", None)
    )

    wsi_extensions = {".svs", ".ndpi", ".tiff", ".tif", ".scn", ".mrxs", ".vms", ".vmu"}
    wsi_paths = [
        str(p) for p in Path(args.wsi_dir).rglob("*")
        if p.suffix.lower() in wsi_extensions
    ]

    if args.split_csv:
        import pandas as pd
        split_df = pd.read_csv(args.split_csv)
        slide_ids = set(split_df["slide_id"].tolist())
        wsi_paths = [p for p in wsi_paths if Path(p).stem in slide_ids]

    print(f"Found {len(wsi_paths)} WSIs")
    total_patches = 0

    for wsi_path in tqdm(wsi_paths, desc="Processing WSIs"):
        try:
            patches = extract_patches_from_wsi(
                wsi_path=wsi_path,
                out_dir=args.out_dir,
                normaliser=normaliser,
                nucleus_density_threshold=dssm.get("nucleus_density_threshold", 0.62),
                patch_size_dense=dssm.get("patch_size_dense", 224),
                patch_size_sparse=dssm.get("patch_size_sparse", 1024),
                target_size=dssm.get("target_size", 224),
                stride_overlap=dssm.get("stride_overlap", 0.5),
            )
            total_patches += len(patches)
        except Exception as e:
            print(f"\nERROR processing {wsi_path}: {e}")
            continue

    print(f"\nDone. Extracted {total_patches} patches from {len(wsi_paths)} WSIs.")
    print(f"Output directory: {args.out_dir}")


if __name__ == "__main__":
    main()
