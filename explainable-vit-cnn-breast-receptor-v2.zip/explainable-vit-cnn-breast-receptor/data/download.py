"""
Download publicly available datasets used in the paper.

Datasets:
  - TCGA-BRCA: https://portal.gdc.cancer.gov/projects/TCGA-BRCA
  - BreaKHis: https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/

BINO Hospital dataset (8,247 WSIs) is proprietary; contact BINO Hospital, Bahawalpur, Pakistan.
External institutional cohorts (SKMH, AKUH, NIH Islamabad) require institutional data sharing agreements.

Usage:
    python data/download.py --dataset tcga_brca --out_dir data/raw/tcga_brca
    python data/download.py --dataset breakhis --out_dir data/raw/breakhis
"""
import argparse
import hashlib
import os
import sys
import urllib.request
from pathlib import Path
from typing import Optional

# SHA-256 checksums for downloaded archives
# [UNVERIFIED]: These must be verified against the actual files after download.
CHECKSUMS = {
    "breakhis_v1.tar.gz": "[UNVERIFIED]",
    "gdc_manifest.txt": "[UNVERIFIED]",
}


def sha256_file(path: str, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def download_with_progress(url: str, dest: str, resume: bool = True) -> None:
    dest_path = Path(dest)
    dest_path.parent.mkdir(parents=True, exist_ok=True)

    existing_bytes = dest_path.stat().st_size if (resume and dest_path.exists()) else 0
    headers = {}
    if existing_bytes > 0:
        headers["Range"] = f"bytes={existing_bytes}-"
        print(f"  Resuming download from byte {existing_bytes:,}...")

    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            total = int(response.headers.get("Content-Length", 0)) + existing_bytes
            mode = "ab" if existing_bytes > 0 else "wb"
            downloaded = existing_bytes
            with open(dest, mode) as f:
                while True:
                    chunk = response.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = 100 * downloaded / total
                        print(f"\r  {pct:.1f}% ({downloaded:,}/{total:,} bytes)", end="", flush=True)
            print()
    except urllib.error.HTTPError as e:
        if e.code == 416 and existing_bytes > 0:
            print("  File already fully downloaded.")
        else:
            raise


def verify_checksum(path: str, expected: str) -> bool:
    if expected == "[UNVERIFIED]":
        print(f"  WARNING: No checksum available for {Path(path).name}. Skipping verification.")
        return True
    actual = sha256_file(path)
    if actual != expected:
        print(f"  CHECKSUM MISMATCH for {path}")
        print(f"    Expected: {expected}")
        print(f"    Got:      {actual}")
        return False
    print(f"  Checksum OK: {actual[:16]}...")
    return True


def download_breakhis(out_dir: str) -> None:
    """
    BreaKHis v1 dataset.
    Source: https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/
    License: CC BY 4.0
    DOI: 10.1109/TBME.2015.2505512
    """
    url = "https://web.inf.ufpr.br/vri/databases/BreaKHis_v1.tar.gz"
    archive = os.path.join(out_dir, "BreaKHis_v1.tar.gz")
    os.makedirs(out_dir, exist_ok=True)
    print(f"Downloading BreaKHis v1 to {archive}")
    print("  Source: https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/")
    print("  License: CC BY 4.0")
    print("  Paper DOI: 10.1109/TBME.2015.2505512")
    try:
        download_with_progress(url, archive)
        verify_checksum(archive, CHECKSUMS.get("breakhis_v1.tar.gz", "[UNVERIFIED]"))
    except Exception as e:
        print(f"\n  Download failed: {e}")
        print("  Please download manually from the URL above and place at:", archive)
        sys.exit(1)


def download_tcga_brca(out_dir: str, token: Optional[str] = None) -> None:
    """
    TCGA-BRCA WSI dataset via GDC Data Portal.
    Source: https://portal.gdc.cancer.gov/projects/TCGA-BRCA
    License: dbGaP (open-access files freely available)
    GDC Data Release: 38.0

    Requires the GDC Data Transfer Tool: https://gdc.cancer.gov/access-data/gdc-data-transfer-tool
    Instructions:
        1. Go to https://portal.gdc.cancer.gov/projects/TCGA-BRCA
        2. Select Files > Slide Image (SVS)
        3. Add to cart, download manifest as gdc_manifest.txt
        4. Install GDC client: https://gdc.cancer.gov/access-data/gdc-data-transfer-tool
        5. Run: gdc-client download -m gdc_manifest.txt -d {out_dir}
    """
    os.makedirs(out_dir, exist_ok=True)
    manifest_path = os.path.join(out_dir, "gdc_manifest.txt")

    print("TCGA-BRCA download instructions:")
    print("  Source: https://portal.gdc.cancer.gov/projects/TCGA-BRCA")
    print("  License: dbGaP (open-access)")
    print("  GDC Data Release: 38.0")
    print()
    print("  1. Install GDC Data Transfer Tool:")
    print("     https://gdc.cancer.gov/access-data/gdc-data-transfer-tool")
    print()
    print("  2. Download manifest file from:")
    print("     https://portal.gdc.cancer.gov/projects/TCGA-BRCA")
    print("     (Files > Slide Image > Download Manifest)")
    print(f"     Save to: {manifest_path}")
    print()
    print("  3. Run GDC client:")
    print(f"     gdc-client download -m {manifest_path} -d {out_dir}")
    print()

    if os.path.exists(manifest_path):
        print(f"  Found manifest at {manifest_path}")
        try:
            import subprocess
            result = subprocess.run(
                ["gdc-client", "--version"],
                capture_output=True, text=True
            )
            print(f"  GDC client: {result.stdout.strip()}")
            print("  Starting download...")
            cmd = ["gdc-client", "download", "-m", manifest_path, "-d", out_dir]
            if token:
                cmd += ["--token-file", token]
            subprocess.run(cmd, check=True)
        except FileNotFoundError:
            print("  ERROR: gdc-client not found. Please install from:")
            print("  https://gdc.cancer.gov/access-data/gdc-data-transfer-tool")
            sys.exit(1)
    else:
        print(f"  No manifest found at {manifest_path}.")
        print("  Please follow the instructions above.")
        sys.exit(0)


def print_bino_instructions() -> None:
    """BINO dataset is proprietary — provide contact information."""
    print("=" * 70)
    print("BINO Hospital Dataset (PRIMARY DATASET — PROPRIETARY)")
    print("=" * 70)
    print()
    print("The primary dataset (8,247 WSIs, 5,632 patients) used in this paper")
    print("is proprietary and belongs to:")
    print()
    print("  Bahawalpur Institute of Nuclear Medicine and Oncology (BINO)")
    print("  Bahawalpur, Pakistan")
    print()
    print("To request access:")
    print("  1. Submit a formal data access request to BINO Hospital")
    print("  2. Obtain IRB/ethics approval from your institution")
    print("  3. Sign a Data Use Agreement (DUA)")
    print()
    print("For reproducibility using public data, use TCGA-BRCA instead:")
    print("  python data/download.py --dataset tcga_brca --out_dir data/raw/tcga_brca")
    print()
    print("Note: Results on TCGA-BRCA are reported in Table 10 of the paper:")
    print("  ER AUC: 0.951±0.019, PR AUC: 0.937±0.022, HER2 AUC: 0.924±0.025")
    print("  Accuracy: 94.3±1.7%")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Download datasets for the ViT-CNN breast cancer receptor prediction paper."
    )
    parser.add_argument(
        "--dataset",
        choices=["tcga_brca", "breakhis", "bino", "all"],
        required=True,
        help="Dataset to download"
    )
    parser.add_argument("--out_dir", default="data/raw", help="Output directory")
    parser.add_argument("--gdc_token", default=None, help="GDC token file for controlled-access data")
    args = parser.parse_args()

    if args.dataset in ("bino", "all"):
        print_bino_instructions()

    if args.dataset in ("tcga_brca", "all"):
        download_tcga_brca(
            os.path.join(args.out_dir, "tcga_brca"),
            token=args.gdc_token
        )

    if args.dataset in ("breakhis", "all"):
        download_breakhis(os.path.join(args.out_dir, "breakhis"))

    if args.dataset not in ("bino", "tcga_brca", "breakhis", "all"):
        print(f"Unknown dataset: {args.dataset}")
        sys.exit(1)


if __name__ == "__main__":
    main()
