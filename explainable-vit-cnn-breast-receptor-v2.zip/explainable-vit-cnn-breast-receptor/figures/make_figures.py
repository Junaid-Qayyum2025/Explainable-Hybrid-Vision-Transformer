"""
Generate all paper figures using matplotlib.

IEEE publication standards:
  Font: Times New Roman, size 10pt (axes labels), 8pt (ticks)
  Resolution: 600 dpi
  Line width: 1.5pt
  Marker size: 6pt

Figures generated:
  fig1_roc_curves.pdf     - ROC curves for ER, PR, HER2 (main model)
  fig2_calibration.pdf    - Reliability diagrams (ECE plot)
  fig3_ablation_auc.pdf   - Bar chart: ablation study AUC
  fig4_fusion_auc.pdf     - Bar chart: fusion strategy AUC
  fig5_uncertainty.pdf    - MC dropout uncertainty distribution
  fig6_confusion.pdf      - Confusion matrices (ER, PR, HER2)

Usage:
    python figures/make_figures.py --results results/reproduced/ --out figures/output/
    python figures/make_figures.py --results results/reproduced/ --expected results/expected/
"""
import argparse
import json
import os
from pathlib import Path
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np

# IEEE publication style
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 10,
    "axes.labelsize": 10,
    "axes.titlesize": 10,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "figure.dpi": 600,
    "lines.linewidth": 1.5,
    "lines.markersize": 6,
    "axes.linewidth": 0.8,
    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "pdf.fonttype": 42,   # TrueType fonts in PDF
    "ps.fonttype": 42,
})

COLORS = {
    "er": "#1f77b4",
    "pr": "#ff7f0e",
    "her2": "#2ca02c",
    "baseline": "#d62728",
    "grey": "#7f7f7f",
}


def load_json(path: str) -> Optional[dict]:
    if not Path(path).exists():
        return None
    with open(path) as f:
        return json.load(f)


def load_predictions(results_dir: Path, split: str = "test") -> Optional[dict]:
    p = results_dir / f"{split}_predictions.json"
    return load_json(str(p))


def fig_roc_curves(preds: dict, out_path: Path) -> None:
    """ROC curves for ER, PR, HER2 receptors."""
    from sklearn.metrics import roc_curve, auc

    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.6))
    labels = ["ER", "PR", "HER2"]
    keys = ["er", "pr", "her2"]
    colors = [COLORS["er"], COLORS["pr"], COLORS["her2"]]

    for ax, label, key, color in zip(axes, labels, keys, colors):
        y_true = np.array(preds[f"{key}_label"])
        y_score = np.array(preds[f"{key}_prob"])
        fpr, tpr, _ = roc_curve(y_true, y_score)
        roc_auc = auc(fpr, tpr)

        ax.plot(fpr, tpr, color=color, lw=1.5, label=f"AUC = {roc_auc:.3f}")
        ax.plot([0, 1], [0, 1], "k--", lw=0.8, alpha=0.5)
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.set_title(label)
        ax.legend(loc="lower right", frameon=False)

    fig.suptitle("ROC Curves", y=1.02)
    plt.tight_layout()
    fig.savefig(str(out_path), dpi=600, bbox_inches="tight", format="pdf")
    plt.close(fig)
    print(f"Saved: {out_path}")


def fig_calibration(preds: dict, n_bins: int = 10, out_path: Path = None) -> None:
    """Reliability diagrams for ER, PR, HER2."""
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.6))
    labels = ["ER", "PR", "HER2"]
    keys = ["er", "pr", "her2"]
    colors = [COLORS["er"], COLORS["pr"], COLORS["her2"]]

    for ax, label, key, color in zip(axes, labels, keys, colors):
        y_true = np.array(preds[f"{key}_label"])
        y_prob = np.array(preds[f"{key}_prob"])

        bin_edges = np.linspace(0, 1, n_bins + 1)
        bin_means_conf = []
        bin_means_acc = []
        bin_counts = []

        for lo, hi in zip(bin_edges[:-1], bin_edges[1:]):
            mask = (y_prob >= lo) & (y_prob < hi)
            if mask.sum() > 0:
                bin_means_conf.append(y_prob[mask].mean())
                bin_means_acc.append(y_true[mask].mean())
                bin_counts.append(mask.sum())

        bin_means_conf = np.array(bin_means_conf)
        bin_means_acc = np.array(bin_means_acc)

        ax.bar(bin_means_conf, bin_means_acc, width=1.0 / n_bins,
               color=color, alpha=0.6, label=label, align="center")
        ax.plot([0, 1], [0, 1], "k--", lw=0.8, alpha=0.7, label="Perfect cal.")
        ax.set_xlim([0, 1])
        ax.set_ylim([0, 1])
        ax.set_xlabel("Mean Confidence")
        ax.set_ylabel("Fraction Positive")
        ax.set_title(label)
        ax.legend(loc="upper left", frameon=False)

    fig.suptitle("Reliability Diagrams", y=1.02)
    plt.tight_layout()
    fig.savefig(str(out_path), dpi=600, bbox_inches="tight", format="pdf")
    plt.close(fig)
    print(f"Saved: {out_path}")


def fig_ablation_bar(ablation_data: dict, out_path: Path) -> None:
    """Grouped bar chart: ablation study AUC across ER, PR, HER2."""
    models = list(ablation_data.keys())
    er_auc = []
    pr_auc = []
    her2_auc = []

    for m in models:
        d = ablation_data[m]
        er_auc.append(float(str(d.get("er_auc", "0")).split("±")[0]))
        pr_auc.append(float(str(d.get("pr_auc", "0")).split("±")[0]))
        her2_auc.append(float(str(d.get("her2_auc", "0")).split("±")[0]))

    x = np.arange(len(models))
    width = 0.25

    fig, ax = plt.subplots(figsize=(7.0, 3.0))
    ax.bar(x - width, er_auc, width, label="ER", color=COLORS["er"], alpha=0.85)
    ax.bar(x, pr_auc, width, label="PR", color=COLORS["pr"], alpha=0.85)
    ax.bar(x + width, her2_auc, width, label="HER2", color=COLORS["her2"], alpha=0.85)

    ax.set_ylabel("AUROC")
    ax.set_title("Ablation Study – Architecture Components")
    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=30, ha="right")
    ax.set_ylim([0.85, 1.0])
    ax.legend(frameon=False)
    ax.yaxis.grid(True, linewidth=0.5, alpha=0.5)
    ax.set_axisbelow(True)

    plt.tight_layout()
    fig.savefig(str(out_path), dpi=600, bbox_inches="tight", format="pdf")
    plt.close(fig)
    print(f"Saved: {out_path}")


def fig_fusion_bar(fusion_data: dict, out_path: Path) -> None:
    """Bar chart: fusion strategy mean AUC."""
    models = list(fusion_data.keys())
    mean_auc = []
    for m in models:
        d = fusion_data[m]
        mean_auc.append(float(str(d.get("mean_auc", "0")).split("±")[0]))

    highlight = [i for i, m in enumerate(models) if "ours" in m.lower() or "cross" in m.lower()]

    colors = [COLORS["er"] if i in highlight else COLORS["grey"] for i in range(len(models))]

    fig, ax = plt.subplots(figsize=(5.5, 2.8))
    bars = ax.barh(models, mean_auc, color=colors, alpha=0.85)
    ax.set_xlabel("Mean AUROC (ER + PR + HER2)")
    ax.set_title("Fusion Strategy Comparison")
    ax.set_xlim([0.88, 0.97])
    ax.xaxis.grid(True, linewidth=0.5, alpha=0.5)
    ax.set_axisbelow(True)

    for bar, val in zip(bars, mean_auc):
        ax.text(val + 0.001, bar.get_y() + bar.get_height() / 2,
                f"{val:.3f}", va="center", ha="left", fontsize=8)

    plt.tight_layout()
    fig.savefig(str(out_path), dpi=600, bbox_inches="tight", format="pdf")
    plt.close(fig)
    print(f"Saved: {out_path}")


def fig_uncertainty(preds: dict, out_path: Path, confidence_threshold: float = 0.85) -> None:
    """MC dropout uncertainty distribution."""
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.6))
    labels = ["ER", "PR", "HER2"]
    keys = ["er", "pr", "her2"]
    colors = [COLORS["er"], COLORS["pr"], COLORS["her2"]]

    for ax, label, key, color in zip(axes, labels, keys, colors):
        var = np.array(preds.get(f"{key}_var", []))
        if len(var) == 0:
            ax.set_title(f"{label} (no MC data)")
            continue
        ax.hist(var, bins=30, color=color, alpha=0.75, density=True)
        ax.axvline(var.mean(), color="k", lw=1.0, linestyle="--",
                   label=f"Mean={var.mean():.5f}")
        ax.set_xlabel("Epistemic Variance")
        ax.set_ylabel("Density")
        ax.set_title(label)
        ax.legend(frameon=False)

    fig.suptitle("MC Dropout Uncertainty (T=30)", y=1.02)
    plt.tight_layout()
    fig.savefig(str(out_path), dpi=600, bbox_inches="tight", format="pdf")
    plt.close(fig)
    print(f"Saved: {out_path}")


def fig_confusion_matrices(preds: dict, out_path: Path) -> None:
    """Confusion matrices for ER, PR, HER2."""
    from sklearn.metrics import confusion_matrix

    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.6))
    labels_list = ["ER", "PR", "HER2"]
    keys = ["er", "pr", "her2"]

    for ax, label, key in zip(axes, labels_list, keys):
        y_true = np.array(preds[f"{key}_label"])
        y_prob = np.array(preds[f"{key}_prob"])
        y_pred = (y_prob >= 0.5).astype(int)
        cm = confusion_matrix(y_true, y_pred)

        im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
        ax.set_title(label)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(["Neg", "Pos"])
        ax.set_yticklabels(["Neg", "Pos"])

        thresh = cm.max() / 2.0
        for i in range(2):
            for j in range(2):
                ax.text(j, i, f"{cm[i, j]}", ha="center", va="center",
                        color="white" if cm[i, j] > thresh else "black", fontsize=8)

    fig.suptitle("Confusion Matrices (threshold = 0.5)", y=1.02)
    plt.tight_layout()
    fig.savefig(str(out_path), dpi=600, bbox_inches="tight", format="pdf")
    plt.close(fig)
    print(f"Saved: {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="results/reproduced/main_model")
    parser.add_argument("--expected", default="results/expected")
    parser.add_argument("--out", default="figures/output")
    parser.add_argument("--split", default="test")
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    results_dir = Path(args.results)
    expected_dir = Path(args.expected)

    # Load per-sample predictions for sample-level figures
    preds = load_predictions(results_dir, args.split)

    if preds is not None:
        print("\nGenerating sample-level figures...")
        try:
            fig_roc_curves(preds, out_dir / "fig1_roc_curves.pdf")
        except Exception as e:
            print(f"  fig1 skipped: {e}")

        try:
            fig_calibration(preds, n_bins=10, out_path=out_dir / "fig2_calibration.pdf")
        except Exception as e:
            print(f"  fig2 skipped: {e}")

        er_var = preds.get("er_var", [])
        if any(v > 0 for v in er_var):
            try:
                fig_uncertainty(preds, out_dir / "fig5_uncertainty.pdf")
            except Exception as e:
                print(f"  fig5 skipped: {e}")

        try:
            fig_confusion_matrices(preds, out_dir / "fig6_confusion.pdf")
        except Exception as e:
            print(f"  fig6 skipped: {e}")
    else:
        print(f"No predictions found at {results_dir}/{args.split}_predictions.json")
        print("Run evaluate_all.py first.")

    # Aggregate-level figures from expected (or reproduced if available)
    print("\nGenerating aggregate figures from expected values...")

    ablation_data = load_json(str(expected_dir / "table6_ablation.json"))
    if ablation_data and "aggregated" in ablation_data:
        try:
            fig_ablation_bar(ablation_data["aggregated"], out_dir / "fig3_ablation_auc.pdf")
        except Exception as e:
            print(f"  fig3 skipped: {e}")

    fusion_data = load_json(str(expected_dir / "table7_fusion.json"))
    if fusion_data and "aggregated" in fusion_data:
        try:
            fig_fusion_bar(fusion_data["aggregated"], out_dir / "fig4_fusion_auc.pdf")
        except Exception as e:
            print(f"  fig4 skipped: {e}")

    print(f"\nAll figures saved to {out_dir}/")


if __name__ == "__main__":
    main()
