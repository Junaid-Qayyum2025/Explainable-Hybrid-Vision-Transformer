#!/usr/bin/env bash
# Train all ablation and fusion variant configs (single seed=42 each).
set -euo pipefail

SEED=42
mkdir -p logs

ABLATION_CONFIGS=(
    "configs/ablation_cnn_only.yaml"
    "configs/ablation_vit_only.yaml"
    "configs/ablation_vit_cnn_no_fusion.yaml"
    "configs/ablation_fixed_224.yaml"
    "configs/ablation_fixed_1024.yaml"
)

FUSION_CONFIGS=(
    "configs/fusion_concat_mlp.yaml"
    "configs/fusion_additive.yaml"
    "configs/fusion_gated.yaml"
    "configs/fusion_film.yaml"
    "configs/fusion_multistage.yaml"
)

echo "=== Architecture ablations ==="
for CFG in "${ABLATION_CONFIGS[@]}"; do
    if [ -f "$CFG" ]; then
        EXP=$(python -c "import yaml; c=yaml.safe_load(open('$CFG')); print(c['experiment_name'])")
        echo "  $EXP (seed $SEED)"
        python train.py --config "$CFG" --seed "$SEED" 2>&1 | tee "logs/${EXP}_seed${SEED}.log"
    fi
done

echo "=== Fusion ablations ==="
for CFG in "${FUSION_CONFIGS[@]}"; do
    if [ -f "$CFG" ]; then
        EXP=$(python -c "import yaml; c=yaml.safe_load(open('$CFG')); print(c['experiment_name'])")
        echo "  $EXP (seed $SEED)"
        python train.py --config "$CFG" --seed "$SEED" 2>&1 | tee "logs/${EXP}_seed${SEED}.log"
    fi
done

echo "Ablation training complete."
