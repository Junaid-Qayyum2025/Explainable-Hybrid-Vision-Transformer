#!/usr/bin/env bash
# Train and evaluate the main model only (seeds 42-46).
set -euo pipefail

CONFIG="${1:-configs/main_model.yaml}"
SEEDS="${2:-42 43 44 45 46}"

mkdir -p logs

for SEED in $SEEDS; do
    echo "=== Training seed $SEED ==="
    python train.py --config "$CONFIG" --seed "$SEED" 2>&1 | tee "logs/train_seed${SEED}.log"
done

echo "=== Evaluating ==="
python evaluate_all.py \
    --config "$CONFIG" \
    --checkpoint_dir checkpoints \
    --seeds $SEEDS \
    --out_dir results/reproduced/main_model

echo "=== Compare ==="
python compare_results.py

echo "Done."
