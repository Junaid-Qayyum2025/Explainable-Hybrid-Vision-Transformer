#!/usr/bin/env bash
# Run complete reproduction pipeline: preprocess → train → evaluate → compare.
# Runtime: ~72h on 1x NVIDIA A100 40GB.
set -euo pipefail

CONFIG="configs/main_model.yaml"
SEEDS="42 43 44 45 46"
LOG_DIR="logs"

echo "============================================================"
echo "  Explainable ViT-CNN Breast Cancer Receptor – Full Pipeline"
echo "============================================================"

# 1. Download public data (TCGA-BRCA, BreaKHis; BINO is proprietary)
echo "[1/7] Downloading public datasets..."
python data/download.py --dataset tcga_brca --out_dir data/raw/tcga_brca
python data/download.py --dataset breakhis   --out_dir data/raw/breakhis

# 2. Preprocess: Macenko normalisation + DSSM patch extraction
echo "[2/7] Preprocessing..."
python data/preprocess.py \
    --wsi_dir data/raw/tcga_brca \
    --out_dir data/processed/tcga_brca \
    --config "$CONFIG"

# 3. Generate splits
echo "[3/7] Generating patient-level 70/15/15 splits..."
python data/generate_splits.py \
    --manifest data/raw/tcga_brca/tcga_brca_slides.csv \
    --out_dir data/splits

# 4. Train all seeds
echo "[4/7] Training main model (5 seeds)..."
for SEED in $SEEDS; do
    echo "  Seed $SEED..."
    python train.py --config "$CONFIG" --seed "$SEED" 2>&1 | tee "$LOG_DIR/train_seed${SEED}.log"
done

# 5. Train ablation and fusion variants
echo "[5/7] Training ablation and fusion variants..."
bash scripts/run_ablation.sh

# 6. Evaluate all and produce result tables
echo "[6/7] Evaluating all checkpoints..."
python evaluate_all.py \
    --config "$CONFIG" \
    --checkpoint_dir checkpoints \
    --seeds $SEEDS

# 7. Compare to paper values
echo "[7/7] Comparing to paper-reported values..."
python compare_results.py \
    --expected results/expected \
    --reproduced results/reproduced

echo ""
echo "Done. See results/reproduced/ for tables and figures/output/ for figures."
