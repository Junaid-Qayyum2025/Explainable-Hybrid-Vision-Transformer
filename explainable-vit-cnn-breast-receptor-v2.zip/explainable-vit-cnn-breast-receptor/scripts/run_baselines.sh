#!/usr/bin/env bash
# Train and evaluate baseline comparison methods (Table 8).
# DCS-ST: configs/baseline_dcs_st.yaml (requires separate baseline config).
set -euo pipefail

SEED=42
mkdir -p logs

BASELINE_CONFIGS=(
    "configs/baseline_dcs_st.yaml"
)

echo "=== Baseline methods ==="
for CFG in "${BASELINE_CONFIGS[@]}"; do
    if [ -f "$CFG" ]; then
        EXP=$(python -c "import yaml; c=yaml.safe_load(open('$CFG')); print(c['experiment_name'])")
        echo "  $EXP"
        python train.py --config "$CFG" --seed "$SEED" 2>&1 | tee "logs/${EXP}.log"
    else
        echo "  Skipping $CFG (not found)"
    fi
done

echo "Done. Add baseline results manually to results/reproduced/ for compare_results.py."
