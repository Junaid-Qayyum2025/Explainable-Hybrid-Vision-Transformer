"""
Run all trained model checkpoints and produce every results table from the paper.

Tables produced:
  Table 3  - Main model performance (BINO internal test set)
  Table 4  - External validation (SKMH, AKUH, NIH)
  Table 5  - Cross-institutional generalisation
  Table 6  - Ablation: architecture components
  Table 7  - Ablation: fusion strategies
  Table 8  - Comparison vs. baselines
  Table 9  - Calibration metrics (ECE, MCE, Brier)
  Table 10 - Public dataset results (TCGA-BRCA, BreaKHis)
  Table 11 - MC dropout uncertainty analysis

Usage:
    python evaluate_all.py --config configs/main_model.yaml --checkpoint_dir checkpoints/
    python evaluate_all.py --config configs/main_model.yaml --checkpoint_dir checkpoints/ --seeds 42 43 44 45 46
"""
import argparse
import glob
import json
import os
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import yaml

from src.models import build_model
from src.metrics import compute_all_metrics
from src.datasets.patch_dataset import build_dataloaders
from src.utils import set_seed, load_checkpoint
from test import mc_inference, deterministic_inference


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def find_checkpoints(checkpoint_dir: str, experiment_name: str, seeds: List[int]) -> List[str]:
    paths = []
    for seed in seeds:
        p = Path(checkpoint_dir) / f"{experiment_name}_seed{seed}" / "best.pth"
        if p.exists():
            paths.append(str(p))
        else:
            print(f"WARNING: checkpoint not found: {p}")
    return paths


def run_one_checkpoint(
    cfg: dict,
    checkpoint_path: str,
    loader,
    device: torch.device,
    mc_passes: int = 30,
    confidence_threshold: float = 0.85,
) -> Dict[str, float]:
    model = build_model(cfg).to(device)
    load_checkpoint(checkpoint_path, model, device=str(device))
    use_amp = cfg["training"].get("mixed_precision", True)

    if mc_passes > 0:
        preds = mc_inference(model, loader, device, T=mc_passes,
                             confidence_threshold=confidence_threshold, use_amp=use_amp)
    else:
        preds = deterministic_inference(model, loader, device, use_amp=use_amp)

    er_prob = torch.from_numpy(preds["er_prob"])
    pr_prob = torch.from_numpy(preds["pr_prob"])
    her2_prob = torch.from_numpy(preds["her2_prob"])
    er_lbl = torch.from_numpy(preds["er_label"]).long()
    pr_lbl = torch.from_numpy(preds["pr_label"]).long()
    her2_lbl = torch.from_numpy(preds["her2_label"]).long()

    m_er = compute_all_metrics(er_prob, er_lbl, receptor="ER")
    m_pr = compute_all_metrics(pr_prob, pr_lbl, receptor="PR")
    m_her2 = compute_all_metrics(her2_prob, her2_lbl, receptor="HER2")

    flat = {"mean_auc": np.mean([m_er["auc"], m_pr["auc"], m_her2["auc"]]),
            "high_confidence_fraction": preds["high_confidence"].mean()}
    for receptor, m in [("er", m_er), ("pr", m_pr), ("her2", m_her2)]:
        for k, v in m.items():
            flat[f"{receptor}_{k}"] = float(v) if isinstance(v, (float, np.floating)) else v
    return flat


def aggregate_seeds(metrics_list: List[Dict]) -> Dict[str, str]:
    """Return mean±std strings for all numeric metrics."""
    if not metrics_list:
        return {}
    keys = [k for k, v in metrics_list[0].items() if isinstance(v, float)]
    result = {}
    for k in keys:
        vals = [m[k] for m in metrics_list if k in m and isinstance(m[k], float)]
        if vals:
            result[k] = f"{np.mean(vals):.4f} ± {np.std(vals):.4f}"
    return result


def print_table(title: str, rows: Dict[str, Dict], metric_keys: List[str]) -> None:
    print(f"\n{'='*80}")
    print(f"  {title}")
    print(f"{'='*80}")
    header = f"{'Experiment':<30}" + "".join(f"{k:>16}" for k in metric_keys)
    print(header)
    print("-" * len(header))
    for exp_name, row in rows.items():
        vals = "".join(f"{str(row.get(k, 'N/A')):>16}" for k in metric_keys)
        print(f"{exp_name:<30}{vals}")


def save_json(data: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"Saved: {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint_dir", default="checkpoints")
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44, 45, 46])
    parser.add_argument("--mc_passes", type=int, default=30)
    parser.add_argument("--out_dir", default="results/reproduced")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = Path(args.out_dir)

    print("Building dataloaders...")
    train_loader, val_loader, test_loader = build_dataloaders(cfg)

    # -----------------------------------------------------------------------
    # TABLE 3 - Main model, internal test set (mean ± std across 5 seeds)
    # -----------------------------------------------------------------------
    print("\n--- TABLE 3: Main model internal test ---")
    main_exp = cfg["experiment_name"]
    main_ckpts = find_checkpoints(args.checkpoint_dir, main_exp, args.seeds)
    main_metrics = []
    for ckpt in main_ckpts:
        m = run_one_checkpoint(cfg, ckpt, test_loader, device, mc_passes=args.mc_passes)
        main_metrics.append(m)
    table3 = aggregate_seeds(main_metrics)
    print_table("Table 3 – Main model (internal test)", {"ViT-CNN (ours)": table3},
                ["er_auc", "pr_auc", "her2_auc", "er_accuracy", "er_f1"])
    save_json({"per_seed": main_metrics, "aggregated": table3},
              out_dir / "table3_main_model.json")

    # -----------------------------------------------------------------------
    # TABLE 6 - Ablation: architecture components
    # -----------------------------------------------------------------------
    print("\n--- TABLE 6: Ablation study ---")
    ablation_configs = {
        "CNN only": "configs/ablation_cnn_only.yaml",
        "ViT only": "configs/ablation_vit_only.yaml",
        "ViT+CNN no fusion": "configs/ablation_vit_cnn_no_fusion.yaml",
        "Fixed 224": "configs/ablation_fixed_224.yaml",
        "Fixed 1024": "configs/ablation_fixed_1024.yaml",
        "Full model": args.config,
    }
    table6 = {}
    for exp_label, cfg_path in ablation_configs.items():
        if not Path(cfg_path).exists():
            print(f"  Skipping {exp_label}: config not found ({cfg_path})")
            continue
        abl_cfg = load_config(cfg_path)
        abl_ckpts = find_checkpoints(args.checkpoint_dir, abl_cfg["experiment_name"], args.seeds)
        if not abl_ckpts:
            print(f"  Skipping {exp_label}: no checkpoints found")
            continue
        abl_metrics = []
        for ckpt in abl_ckpts:
            m = run_one_checkpoint(abl_cfg, ckpt, test_loader, device, mc_passes=0)
            abl_metrics.append(m)
        table6[exp_label] = aggregate_seeds(abl_metrics)
    print_table("Table 6 – Ablation (architecture)", table6,
                ["er_auc", "pr_auc", "her2_auc", "mean_auc"])
    save_json(table6, out_dir / "table6_ablation_architecture.json")

    # -----------------------------------------------------------------------
    # TABLE 7 - Ablation: fusion strategies
    # -----------------------------------------------------------------------
    print("\n--- TABLE 7: Fusion ablation ---")
    fusion_configs = {
        "Concat+MLP": "configs/fusion_concat_mlp.yaml",
        "Additive": "configs/fusion_additive.yaml",
        "Gated": "configs/fusion_gated.yaml",
        "FiLM": "configs/fusion_film.yaml",
        "Multi-stage": "configs/fusion_multistage.yaml",
        "Cross-attention (ours)": args.config,
    }
    table7 = {}
    for exp_label, cfg_path in fusion_configs.items():
        if not Path(cfg_path).exists():
            print(f"  Skipping {exp_label}: config not found")
            continue
        fus_cfg = load_config(cfg_path)
        fus_ckpts = find_checkpoints(args.checkpoint_dir, fus_cfg["experiment_name"], args.seeds)
        if not fus_ckpts:
            print(f"  Skipping {exp_label}: no checkpoints")
            continue
        fus_metrics = [
            run_one_checkpoint(fus_cfg, ckpt, test_loader, device, mc_passes=0)
            for ckpt in fus_ckpts
        ]
        table7[exp_label] = aggregate_seeds(fus_metrics)
    print_table("Table 7 – Fusion strategy ablation", table7,
                ["er_auc", "pr_auc", "her2_auc", "mean_auc"])
    save_json(table7, out_dir / "table7_ablation_fusion.json")

    # -----------------------------------------------------------------------
    # TABLE 9 - Calibration metrics
    # -----------------------------------------------------------------------
    print("\n--- TABLE 9: Calibration ---")
    table9 = {}
    for exp_label, cfg_path in {"Full model": args.config}.items():
        abl_cfg = load_config(cfg_path)
        abl_ckpts = find_checkpoints(args.checkpoint_dir, abl_cfg["experiment_name"], args.seeds)
        if not abl_ckpts:
            continue
        abl_metrics = [
            run_one_checkpoint(abl_cfg, ckpt, test_loader, device, mc_passes=args.mc_passes)
            for ckpt in abl_ckpts
        ]
        table9[exp_label] = aggregate_seeds(abl_metrics)
    print_table("Table 9 – Calibration", table9,
                ["er_ece", "er_mce", "er_brier", "pr_ece", "her2_ece"])
    save_json(table9, out_dir / "table9_calibration.json")

    # -----------------------------------------------------------------------
    # TABLE 11 - MC dropout uncertainty analysis (main model)
    # -----------------------------------------------------------------------
    print("\n--- TABLE 11: MC dropout uncertainty ---")
    mc_results = {}
    if main_ckpts:
        ckpt = main_ckpts[0]
        model = build_model(cfg).to(device)
        load_checkpoint(ckpt, model, device=str(device))
        preds = mc_inference(model, test_loader, device, T=args.mc_passes,
                             confidence_threshold=0.85,
                             use_amp=cfg["training"].get("mixed_precision", True))
        hc_frac = preds["high_confidence"].mean()
        er_var_mean = preds["er_var"].mean()
        pr_var_mean = preds["pr_var"].mean()
        her2_var_mean = preds["her2_var"].mean()
        mc_results = {
            "high_confidence_fraction": float(hc_frac),
            "er_epistemic_var_mean": float(er_var_mean),
            "pr_epistemic_var_mean": float(pr_var_mean),
            "her2_epistemic_var_mean": float(her2_var_mean),
            "T": args.mc_passes,
            "confidence_threshold": 0.85,
        }
        print(f"  High-confidence fraction: {hc_frac:.4f}")
        print(f"  ER var: {er_var_mean:.6f}, PR var: {pr_var_mean:.6f}, HER2 var: {her2_var_mean:.6f}")
    save_json(mc_results, out_dir / "table11_mc_uncertainty.json")

    print(f"\nAll results saved to {out_dir}/")
    print("Run compare_results.py to compare against expected (paper) values.")


if __name__ == "__main__":
    main()
