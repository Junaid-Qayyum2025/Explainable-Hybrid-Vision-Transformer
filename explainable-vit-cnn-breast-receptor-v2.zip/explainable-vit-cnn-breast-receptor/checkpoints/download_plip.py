"""
Download PLIP (Pathology Language and Image Pre-Training) weights.

Source: https://huggingface.co/vinid/plip
Paper: Huang et al. (2023), Nature Medicine 29, 2039-2049.
       doi:10.1038/s41591-023-02504-3

The PLIPViTBranch in src/models/vit_branch.py loads these weights
automatically via HuggingFace transformers (CLIPModel.from_pretrained).
Run this script once to cache them locally before training without
internet access.
"""
import argparse
import os


def download_plip(cache_dir: str = "checkpoints/plip") -> None:
    os.makedirs(cache_dir, exist_ok=True)
    print(f"Downloading PLIP weights to {cache_dir} ...")
    print("Model: vinid/plip  (HuggingFace Hub)")
    print("Size: ~600MB (ViT-Base/32 + text encoder)")

    try:
        from transformers import CLIPModel, CLIPProcessor
        model = CLIPModel.from_pretrained("vinid/plip", cache_dir=cache_dir)
        processor = CLIPProcessor.from_pretrained("vinid/plip", cache_dir=cache_dir)
        print(f"PLIP weights cached at: {cache_dir}")
        print(f"  Vision model params: {sum(p.numel() for p in model.vision_model.parameters()):,}")
    except Exception as e:
        print(f"Download failed: {e}")
        print("\nManual download:")
        print("  1. Install git-lfs: https://git-lfs.com/")
        print("  2. git clone https://huggingface.co/vinid/plip checkpoints/plip")
        print("\nAlternatively, the model is loaded on-the-fly during training")
        print("if internet access is available (requires transformers>=4.35.0).")
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", default="checkpoints/plip")
    args = parser.parse_args()
    download_plip(args.cache_dir)


if __name__ == "__main__":
    main()
