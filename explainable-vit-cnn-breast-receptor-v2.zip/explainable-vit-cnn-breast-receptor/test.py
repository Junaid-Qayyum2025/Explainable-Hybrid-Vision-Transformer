"""
Inference and evaluation script with Monte Carlo dropout uncertainty estimation.

Paper MC dropout: T=30 forward passes, confidence threshold=0.85
Outputs: per-sample predictions, uncertainty scores, confusion matrices, calibration.

Usage:
    python test.py --config configs/main_model.yaml --checkpoint checkpoints/main_model_seed42/best.pth
    python test.py --config configs/main_model.yaml --checkpoint checkpoints/main_model_seed42/best.pth --split test
    python test.py --config configs/main_model.yaml --checkpoint checkpoints/main_model_seed42/best.pth --mc_passes 30
"""
import argparse
import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.cuda.amp import autocast
import yaml

from src.models import build_model
from src.losses import MultiTaskReceptorLoss
from src.metrics import ReceptorMetrics, compute_all_metrics
from src.datasets.patch_dataset import build_dataloaders
from src.utils import set_seed, load_checkpoint


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def mc_inference(
    model: nn.Module,
    loader,
    device: torch.device,
    T: int = 30,
    confidence_threshold: float = 0.85,
    use_amp: bool = True,
) -> Dict[str, np.ndarray]:
    """
    Run T stochastic forward passes with MC dropout enabled.

    Returns per-sample: mean probability, variance, epistemic uncertainty flag.
    """
    model.train()  # enables dropout

    all_er_mean, all_er_var = [], []
    all_pr_mean, all_pr_var = [], []
    all_her2_mean, all_her2_var = [], []
    all_er_labels, all_pr_labels, all_her2_labels = [], [], []
    all_subtype_logits_mean, all_subtype_labels = [], []
    all_sample_ids = []

    with torch.no_grad():
        for batch in loader:
            images = batch["image"].to(device, non_blocking=True)
            er_label = batch["er_label"].cpu().numpy()
            pr_label = batch["pr_label"].cpu().numpy()
            her2_label = batch["her2_label"].cpu().numpy()
            subtype_label = batch["subtype_label"].cpu().numpy()

            er_preds, pr_preds, her2_preds, subtype_preds = [], [], [], []

            for _ in range(T):
                with autocast(enabled=use_amp):
                    out = model(images)
                er_preds.append(out["er_prob"].cpu().numpy())
                pr_preds.append(out["pr_prob"].cpu().numpy())
                her2_preds.append(out["her2_prob"].cpu().numpy())
                subtype_preds.append(
                    torch.softmax(out["subtype_logits"], dim=1).cpu().numpy()
                )

            er_arr = np.stack(er_preds, axis=0)    # (T, B)
            pr_arr = np.stack(pr_preds, axis=0)
            her2_arr = np.stack(her2_preds, axis=0)
            sub_arr = np.stack(subtype_preds, axis=0)  # (T, B, 4)

            all_er_mean.append(er_arr.mean(0))
            all_er_var.append(er_arr.var(0))
            all_pr_mean.append(pr_arr.mean(0))
            all_pr_var.append(pr_arr.var(0))
            all_her2_mean.append(her2_arr.mean(0))
            all_her2_var.append(her2_arr.var(0))
            all_er_labels.append(er_label)
            all_pr_labels.append(pr_label)
            all_her2_labels.append(her2_label)
            all_subtype_logits_mean.append(sub_arr.mean(0))
            all_subtype_labels.append(subtype_label)

            if "sample_id" in batch:
                all_sample_ids.extend(batch["sample_id"])

    er_mean = np.concatenate(all_er_mean)
    er_var = np.concatenate(all_er_var)
    pr_mean = np.concatenate(all_pr_mean)
    pr_var = np.concatenate(all_pr_var)
    her2_mean = np.concatenate(all_her2_mean)
    her2_var = np.concatenate(all_her2_var)

    # Confidence flag: True if all three receptors exceed threshold
    er_conf = np.maximum(er_mean, 1 - er_mean)
    pr_conf = np.maximum(pr_mean, 1 - pr_mean)
    her2_conf = np.maximum(her2_mean, 1 - her2_mean)
    high_confidence = (
        (er_conf >= confidence_threshold) &
        (pr_conf >= confidence_threshold) &
        (her2_conf >= confidence_threshold)
    )

    return {
        "er_prob": er_mean,
        "er_var": er_var,
        "pr_prob": pr_mean,
        "pr_var": pr_var,
        "her2_prob": her2_mean,
        "her2_var": her2_var,
        "er_label": np.concatenate(all_er_labels),
        "pr_label": np.concatenate(all_pr_labels),
        "her2_label": np.concatenate(all_her2_labels),
        "subtype_prob": np.concatenate(all_subtype_logits_mean),
        "subtype_label": np.concatenate(all_subtype_labels),
        "high_confidence": high_confidence,
        "sample_ids": all_sample_ids,
    }


@torch.no_grad()
def deterministic_inference(
    model: nn.Module,
    loader,
    device: torch.device,
    use_amp: bool = True,
) -> Dict[str, np.ndarray]:
    """Single-pass deterministic inference."""
    model.eval()

    all_er, all_pr, all_her2 = [], [], []
    all_er_lbl, all_pr_lbl, all_her2_lbl, all_sub_lbl = [], [], [], []
    all_subtype = []
    all_sample_ids = []

    for batch in loader:
        images = batch["image"].to(device, non_blocking=True)

        with autocast(enabled=use_amp):
            out = model(images)

        all_er.append(out["er_prob"].cpu().numpy())
        all_pr.append(out["pr_prob"].cpu().numpy())
        all_her2.append(out["her2_prob"].cpu().numpy())
        all_subtype.append(
            torch.softmax(out["subtype_logits"], dim=1).cpu().numpy()
        )
        all_er_lbl.append(batch["er_label"].numpy())
        all_pr_lbl.append(batch["pr_label"].numpy())
        all_her2_lbl.append(batch["her2_label"].numpy())
        all_sub_lbl.append(batch["subtype_label"].numpy())

        if "sample_id" in batch:
            all_sample_ids.extend(batch["sample_id"])

    return {
        "er_prob": np.concatenate(all_er),
        "er_var": np.zeros(len(np.concatenate(all_er))),
        "pr_prob": np.concatenate(all_pr),
        "pr_var": np.zeros(len(np.concatenate(all_pr))),
        "her2_prob": np.concatenate(all_her2),
        "her2_var": np.zeros(len(np.concatenate(all_her2))),
        "er_label": np.concatenate(all_er_lbl),
        "pr_label": np.concatenate(all_pr_lbl),
        "her2_label": np.concatenate(all_her2_lbl),
        "subtype_prob": np.concatenate(all_subtype),
        "subtype_label": np.concatenate(all_sub_lbl),
        "high_confidence": np.ones(len(np.concatenate(all_er)), dtype=bool),
        "sample_ids": all_sample_ids,
    }


def print_metrics_table(results: Dict[str, Dict], label: str) -> None:
    print(f"\n{'='*70}")
    print(f"{label}")
    print(f"{'='*70}")
    for receptor in ["er", "pr", "her2"]:
        r = results.get(receptor, {})
        print(f"\n  {receptor.upper()}:")
        for k, v in r.items():
            if isinstance(v, float):
                print(f"    {k:20s}: {v:.4f}")


def save_predictions(preds: Dict, out_dir: Path, split: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    out = {
        "er_prob": preds["er_prob"].tolist(),
        "er_var": preds["er_var"].tolist(),
        "pr_prob": preds["pr_prob"].tolist(),
        "pr_var": preds["pr_var"].tolist(),
        "her2_prob": preds["her2_prob"].tolist(),
        "her2_var": preds["her2_var"].tolist(),
        "er_label": preds["er_label"].tolist(),
        "pr_label": preds["pr_label"].tolist(),
        "her2_label": preds["her2_label"].tolist(),
        "subtype_prob": preds["subtype_prob"].tolist(),
        "subtype_label": preds["subtype_label"].tolist(),
        "high_confidence": preds["high_confidence"].tolist(),
        "sample_ids": preds["sample_ids"],
    }
    with open(out_dir / f"{split}_predictions.json", "w") as f:
        json.dump(out, f, indent=2)
    print(f"Predictions saved to {out_dir / f'{split}_predictions.json'}")


def main():
    parser = argparse.ArgumentParser(description="Test ViT-CNN breast cancer receptor model.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--split", default="test", choices=["train", "val", "test"])
    parser.add_argument("--mc_passes", type=int, default=30,
                        help="Number of MC dropout passes (0 = deterministic)")
    parser.add_argument("--confidence_threshold", type=float, default=0.85)
    parser.add_argument("--out_dir", default=None)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    print(f"Checkpoint: {args.checkpoint}")
    print(f"Split: {args.split}, MC passes: {args.mc_passes}")

    train_loader, val_loader, test_loader = build_dataloaders(cfg)
    loader_map = {"train": train_loader, "val": val_loader, "test": test_loader}
    loader = loader_map[args.split]

    model = build_model(cfg).to(device)
    load_checkpoint(args.checkpoint, model, device=str(device))

    use_amp = cfg["training"].get("mixed_precision", True)

    if args.mc_passes > 0:
        print(f"\nRunning MC dropout inference (T={args.mc_passes})...")
        preds = mc_inference(
            model, loader, device,
            T=args.mc_passes,
            confidence_threshold=args.confidence_threshold,
            use_amp=use_amp,
        )
        print(f"High-confidence samples: {preds['high_confidence'].sum()} / {len(preds['high_confidence'])}")
    else:
        print("\nRunning deterministic inference...")
        preds = deterministic_inference(model, loader, device, use_amp=use_amp)

    # Convert numpy arrays to torch tensors for metrics
    er_prob_t = torch.from_numpy(preds["er_prob"])
    pr_prob_t = torch.from_numpy(preds["pr_prob"])
    her2_prob_t = torch.from_numpy(preds["her2_prob"])
    er_lbl_t = torch.from_numpy(preds["er_label"]).long()
    pr_lbl_t = torch.from_numpy(preds["pr_label"]).long()
    her2_lbl_t = torch.from_numpy(preds["her2_label"]).long()

    metrics_er = compute_all_metrics(er_prob_t, er_lbl_t, receptor="ER")
    metrics_pr = compute_all_metrics(pr_prob_t, pr_lbl_t, receptor="PR")
    metrics_her2 = compute_all_metrics(her2_prob_t, her2_lbl_t, receptor="HER2")

    results = {"er": metrics_er, "pr": metrics_pr, "her2": metrics_her2}
    print_metrics_table(results, f"Results ({args.split} set)")

    mean_auc = np.mean([
        metrics_er.get("auc", 0),
        metrics_pr.get("auc", 0),
        metrics_her2.get("auc", 0),
    ])
    print(f"\n  Mean AUC: {mean_auc:.4f}")

    # Save outputs
    exp_name = cfg.get("experiment_name", "experiment")
    out_dir = Path(args.out_dir) if args.out_dir else Path("results/reproduced") / exp_name
    save_predictions(preds, out_dir, args.split)

    metrics_out = {
        "split": args.split,
        "checkpoint": args.checkpoint,
        "mc_passes": args.mc_passes,
        "er": {k: float(v) if isinstance(v, (float, np.floating)) else v
               for k, v in metrics_er.items()},
        "pr": {k: float(v) if isinstance(v, (float, np.floating)) else v
               for k, v in metrics_pr.items()},
        "her2": {k: float(v) if isinstance(v, (float, np.floating)) else v
                 for k, v in metrics_her2.items()},
        "mean_auc": float(mean_auc),
    }
    with open(out_dir / f"{args.split}_metrics.json", "w") as f:
        json.dump(metrics_out, f, indent=2)
    print(f"Metrics saved to {out_dir / f'{args.split}_metrics.json'}")


if __name__ == "__main__":
    main()
