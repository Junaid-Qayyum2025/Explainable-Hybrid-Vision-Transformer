"""Unit tests for evaluation metrics."""
import numpy as np
import pytest
import torch

from src.metrics.metrics import ReceptorMetrics, compute_all_metrics, compute_ece


class TestComputeAllMetrics:
    def _make_inputs(self, n=200, auc_target=0.85, seed=0):
        rng = np.random.default_rng(seed)
        labels = rng.integers(0, 2, n)
        # Scores biased toward true label for controllable AUC
        scores = labels * auc_target + (1 - labels) * (1 - auc_target)
        scores = scores + rng.normal(0, 0.1, n)
        scores = np.clip(scores, 0, 1)
        return torch.from_numpy(scores.astype(np.float32)), torch.from_numpy(labels.astype(np.long))

    def test_keys_present(self):
        probs, labels = self._make_inputs()
        m = compute_all_metrics(probs, labels, receptor="ER")
        for key in ["auc", "accuracy", "sensitivity", "specificity", "ppv", "npv",
                    "f1", "mcc", "brier", "ece", "mce"]:
            assert key in m, f"Missing: {key}"

    def test_auc_range(self):
        probs, labels = self._make_inputs()
        m = compute_all_metrics(probs, labels, receptor="ER")
        assert 0.0 <= m["auc"] <= 1.0

    def test_perfect_predictions(self):
        n = 100
        labels = torch.cat([torch.zeros(50), torch.ones(50)]).long()
        probs = torch.cat([torch.zeros(50) + 0.01, torch.ones(50) - 0.01])
        m = compute_all_metrics(probs, labels, receptor="ER")
        assert m["auc"] > 0.99
        assert m["accuracy"] > 0.98

    def test_random_predictions(self):
        torch.manual_seed(0)
        n = 500
        labels = torch.randint(0, 2, (n,))
        probs = torch.rand(n)
        m = compute_all_metrics(probs, labels, receptor="ER")
        # Random classifier AUC should be near 0.5
        assert 0.4 < m["auc"] < 0.65

    def test_ece_perfect_calibration(self):
        """Perfectly calibrated predictions → ECE near 0."""
        n = 1000
        probs = torch.linspace(0.05, 0.95, n)
        # Labels match probability exactly
        torch.manual_seed(42)
        labels = torch.bernoulli(probs).long()
        ece = compute_ece(probs.numpy(), labels.numpy(), n_bins=10)
        assert ece < 5.0  # < 5 pp for well-calibrated

    def test_brier_range(self):
        probs, labels = self._make_inputs()
        m = compute_all_metrics(probs, labels, receptor="ER")
        assert 0.0 <= m["brier"] <= 1.0

    def test_mcc_range(self):
        probs, labels = self._make_inputs()
        m = compute_all_metrics(probs, labels, receptor="ER")
        assert -1.0 <= m["mcc"] <= 1.0


class TestReceptorMetrics:
    def test_accumulate_and_compute(self):
        metrics = ReceptorMetrics()
        n = 100
        for _ in range(3):  # 3 batches
            er_prob = torch.sigmoid(torch.randn(n))
            pr_prob = torch.sigmoid(torch.randn(n))
            her2_prob = torch.sigmoid(torch.randn(n))
            er_lbl = torch.randint(0, 2, (n,))
            pr_lbl = torch.randint(0, 2, (n,))
            her2_lbl = torch.randint(0, 2, (n,))
            sub_logits = torch.randn(n, 4)
            sub_lbl = torch.randint(0, 4, (n,))
            metrics.update(er_prob, pr_prob, her2_prob, er_lbl, pr_lbl, her2_lbl,
                           sub_logits, sub_lbl)

        result = metrics.compute()
        assert "er" in result
        assert "pr" in result
        assert "her2" in result
        assert "mean_auc" in result
        assert 0.0 <= result["mean_auc"] <= 1.0

    def test_reset(self):
        metrics = ReceptorMetrics()
        n = 50
        er_prob = torch.sigmoid(torch.randn(n))
        er_lbl = torch.randint(0, 2, (n,))
        pr_prob = torch.sigmoid(torch.randn(n))
        pr_lbl = torch.randint(0, 2, (n,))
        her2_prob = torch.sigmoid(torch.randn(n))
        her2_lbl = torch.randint(0, 2, (n,))
        sub = torch.randn(n, 4)
        sub_lbl = torch.randint(0, 4, (n,))

        metrics.update(er_prob, pr_prob, her2_prob, er_lbl, pr_lbl, her2_lbl, sub, sub_lbl)
        metrics.reset()
        assert len(metrics.er_probs) == 0
        assert len(metrics.er_labels) == 0
