"""
Unit tests for model forward passes.

These tests use small dummy inputs and do NOT require GPU or PLIP weights.
The PLIPViTBranch falls back to a ViT-Base-like architecture when huggingface
is unavailable, which is appropriate for CI.
"""
import pytest
import torch
import torch.nn as nn


@pytest.fixture
def dummy_cfg():
    return {
        "model": {
            "name": "ViTCNNFusion",
            "vit": {
                "model_name": "vinid/plip",
                "frozen_blocks": 0,
                "dropout": 0.10,
                "hidden_size": 768,
                "num_hidden_layers": 2,
                "num_attention_heads": 8,
                "intermediate_size": 1024,
            },
            "cnn": {
                "backbone": "resnet50",
                "pretrained": False,
                "spatial_attention": True,
                "dilated_stages": [3, 4],
                "dilation_rates": [2, 4],
                "dropout": 0.15,
                "output_channels": 1024,
            },
            "fusion": {
                "type": "cross_attention",
                "num_heads": 4,
                "head_dim": 64,
                "d_model": 256,
                "dropout": 0.10,
                "vit_dim": 768,
                "cnn_dim": 1024,
            },
            "mc_dropout": {
                "T": 5,
                "confidence_threshold": 0.85,
            },
            "n_receptor_classes": 2,
            "n_subtypes": 4,
        },
        "optimizer": {
            "lr": 2e-5,
            "plip_lr": 5e-6,
            "beta1": 0.9,
            "beta2": 0.999,
            "eps": 1e-8,
            "weight_decay": 1e-4,
        },
    }


class TestViTBranch:
    def test_forward_shape(self, dummy_cfg):
        from src.models.vit_branch import PLIPViTBranch
        branch = PLIPViTBranch(dummy_cfg["model"]["vit"])
        B = 4
        x = torch.randn(B, 3, 224, 224)
        cls_tok, patch_toks = branch(x)
        assert cls_tok.shape == (B, 768), f"cls_tok shape: {cls_tok.shape}"
        assert patch_toks.shape[0] == B
        assert patch_toks.shape[2] == 768

    def test_trainable_params(self, dummy_cfg):
        from src.models.vit_branch import PLIPViTBranch
        branch = PLIPViTBranch(dummy_cfg["model"]["vit"])
        param_groups = branch.get_trainable_params(plip_lr=5e-6, global_lr=2e-5)
        assert len(param_groups) >= 1
        for g in param_groups:
            assert "params" in g
            assert "lr" in g


class TestCNNBranch:
    def test_forward_shape(self, dummy_cfg):
        from src.models.cnn_branch import ResNet50AttentionBranch
        branch = ResNet50AttentionBranch(dummy_cfg["model"]["cnn"])
        B = 4
        x = torch.randn(B, 3, 224, 224)
        pool_feat, spatial_toks = branch(x)
        assert pool_feat.shape == (B, 1024), f"pool_feat: {pool_feat.shape}"
        assert spatial_toks.shape[0] == B
        assert spatial_toks.shape[2] == 1024

    def test_spatial_attention_gate(self):
        from src.models.cnn_branch import SpatialAttentionGate
        gate = SpatialAttentionGate(in_channels=256)
        B, C, H, W = 2, 256, 14, 14
        feat = torch.randn(B, C, H, W)
        out = gate(feat)
        assert out.shape == feat.shape
        # Attention weights should be in [0, 1]
        with torch.no_grad():
            raw_logits = gate.conv2(torch.relu(gate.bn(gate.conv1(feat))))
            attn = torch.sigmoid(raw_logits)
        assert attn.min() >= 0.0 and attn.max() <= 1.0


class TestCrossAttentionFusion:
    def test_forward_shape(self, dummy_cfg):
        from src.models.cross_attention_fusion import CrossAttentionFusion
        cfg = dummy_cfg["model"]["fusion"]
        fusion = CrossAttentionFusion(cfg)
        B = 4
        vit_cls = torch.randn(B, 768)
        vit_patches = torch.randn(B, 196, 768)
        cnn_pool = torch.randn(B, 1024)
        cnn_spatial = torch.randn(B, 49, 1024)
        out = fusion(vit_cls, vit_patches, cnn_pool, cnn_spatial)
        assert out.shape[0] == B, f"Batch dim mismatch: {out.shape}"

    def test_fusion_registry(self, dummy_cfg):
        from src.models.cross_attention_fusion import build_fusion
        cfg = dummy_cfg["model"]["fusion"]
        fusion = build_fusion(cfg)
        assert fusion is not None


class TestFullModel:
    @pytest.mark.slow
    def test_main_model_forward(self, dummy_cfg):
        """End-to-end forward pass of the full model."""
        from src.models.vit_cnn_fusion import ViTCNNFusion
        model = ViTCNNFusion(dummy_cfg["model"])
        model.eval()
        B = 2
        x = torch.randn(B, 3, 224, 224)
        with torch.no_grad():
            out = model(x)
        assert "er_prob" in out
        assert "pr_prob" in out
        assert "her2_prob" in out
        assert "subtype_logits" in out
        assert out["er_prob"].shape == (B,)
        assert out["subtype_logits"].shape == (B, 4)
        # Probabilities in [0, 1]
        for key in ["er_prob", "pr_prob", "her2_prob"]:
            assert out[key].min() >= 0.0
            assert out[key].max() <= 1.0

    @pytest.mark.slow
    def test_mc_forward(self, dummy_cfg):
        from src.models.vit_cnn_fusion import ViTCNNFusion
        model = ViTCNNFusion(dummy_cfg["model"])
        B = 2
        x = torch.randn(B, 3, 224, 224)
        out = model.mc_forward(x, T=dummy_cfg["model"]["mc_dropout"]["T"])
        for key in ["er_mean", "er_var", "pr_mean", "pr_var", "her2_mean", "her2_var"]:
            assert key in out
            assert out[key].shape == (B,)
        # Variance must be non-negative
        for key in ["er_var", "pr_var", "her2_var"]:
            assert out[key].min() >= 0.0

    @pytest.mark.slow
    def test_count_parameters(self, dummy_cfg):
        from src.models.vit_cnn_fusion import ViTCNNFusion
        model = ViTCNNFusion(dummy_cfg["model"])
        counts = model.count_parameters()
        assert "total" in counts
        assert counts["total"] > 0

    @pytest.mark.slow
    def test_cnn_only_model(self, dummy_cfg):
        from src.models.vit_cnn_fusion import build_model
        cfg_cnn = dict(dummy_cfg)
        cfg_cnn["model"] = dict(dummy_cfg["model"])
        cfg_cnn["model"]["name"] = "CNNOnly"
        model = build_model(cfg_cnn)
        model.eval()
        B = 2
        x = torch.randn(B, 3, 224, 224)
        with torch.no_grad():
            out = model(x)
        assert "er_prob" in out
