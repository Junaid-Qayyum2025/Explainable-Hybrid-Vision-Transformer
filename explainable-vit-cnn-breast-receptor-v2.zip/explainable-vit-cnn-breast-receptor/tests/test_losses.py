"""Unit tests for focal loss and multi-task loss."""
import pytest
import torch
import torch.nn.functional as F

from src.losses.focal_loss import FocalLoss
from src.losses.multi_task_loss import MultiTaskReceptorLoss


@pytest.fixture
def dummy_cfg():
    return {
        "loss": {
            "receptor_loss": "focal",
            "focal_gamma": 2.0,
            "focal_alpha": 0.25,
            "weight_er": 0.40,
            "weight_pr": 0.30,
            "weight_her2": 0.30,
            "weight_subtype": 0.20,
        }
    }


class TestFocalLoss:
    def test_output_shape(self):
        criterion = FocalLoss(gamma=2.0, alpha=0.25)
        B = 16
        logits = torch.randn(B)
        targets = torch.randint(0, 2, (B,)).float()
        loss = criterion(logits, targets)
        assert loss.shape == ()  # scalar

    def test_perfect_predictions_low_loss(self):
        """Near-perfect predictions should produce near-zero focal loss."""
        criterion = FocalLoss(gamma=2.0, alpha=0.25, reduction="mean")
        B = 32
        targets = torch.randint(0, 2, (B,)).float()
        # logits strongly aligned with targets
        logits = (targets * 2 - 1) * 10.0
        loss = criterion(logits, targets)
        assert loss.item() < 0.01

    def test_loss_positive(self):
        criterion = FocalLoss(gamma=2.0, alpha=0.25)
        B = 8
        logits = torch.randn(B)
        targets = torch.randint(0, 2, (B,)).float()
        loss = criterion(logits, targets)
        assert loss.item() >= 0.0

    def test_gamma_reduces_easy_samples(self):
        """Higher gamma should down-weight easy samples more."""
        logit = torch.tensor([5.0])  # confident positive prediction
        target = torch.tensor([1.0])

        loss_gamma0 = FocalLoss(gamma=0.0, alpha=1.0)(logit, target).item()
        loss_gamma2 = FocalLoss(gamma=2.0, alpha=1.0)(logit, target).item()
        assert loss_gamma2 < loss_gamma0

    def test_no_reduction(self):
        criterion = FocalLoss(gamma=2.0, alpha=0.25, reduction="none")
        B = 8
        logits = torch.randn(B)
        targets = torch.randint(0, 2, (B,)).float()
        loss = criterion(logits, targets)
        assert loss.shape == (B,)


class TestMultiTaskLoss:
    def test_output_keys(self, dummy_cfg):
        criterion = MultiTaskReceptorLoss(dummy_cfg)
        B = 8
        preds = {
            "er_prob": torch.sigmoid(torch.randn(B)),
            "pr_prob": torch.sigmoid(torch.randn(B)),
            "her2_prob": torch.sigmoid(torch.randn(B)),
            "subtype_logits": torch.randn(B, 4),
        }
        er_lbl = torch.randint(0, 2, (B,)).float()
        pr_lbl = torch.randint(0, 2, (B,)).float()
        her2_lbl = torch.randint(0, 2, (B,)).float()
        sub_lbl = torch.randint(0, 4, (B,)).long()

        losses = criterion(preds, er_lbl, pr_lbl, her2_lbl, sub_lbl)
        for key in ["l_er", "l_pr", "l_her2", "l_subtype", "l_total", "l_final"]:
            assert key in losses, f"Missing key: {key}"

    def test_loss_weights(self, dummy_cfg):
        """l_final should be l_total + 0.20 * l_subtype."""
        criterion = MultiTaskReceptorLoss(dummy_cfg)
        B = 8
        preds = {
            "er_prob": torch.sigmoid(torch.randn(B)),
            "pr_prob": torch.sigmoid(torch.randn(B)),
            "her2_prob": torch.sigmoid(torch.randn(B)),
            "subtype_logits": torch.randn(B, 4),
        }
        er_lbl = torch.randint(0, 2, (B,)).float()
        pr_lbl = torch.randint(0, 2, (B,)).float()
        her2_lbl = torch.randint(0, 2, (B,)).float()
        sub_lbl = torch.randint(0, 4, (B,)).long()

        losses = criterion(preds, er_lbl, pr_lbl, her2_lbl, sub_lbl)
        expected_final = losses["l_total"] + 0.20 * losses["l_subtype"]
        assert abs(losses["l_final"].item() - expected_final.item()) < 1e-5

    def test_all_positive(self, dummy_cfg):
        """All-positive predictions with correct labels should give low loss."""
        criterion = MultiTaskReceptorLoss(dummy_cfg)
        B = 16
        # All positive class with confident predictions
        preds = {
            "er_prob": torch.ones(B) * 0.99,
            "pr_prob": torch.ones(B) * 0.99,
            "her2_prob": torch.ones(B) * 0.99,
            "subtype_logits": torch.zeros(B, 4).scatter_(1, torch.zeros(B, 1).long(), 10.0),
        }
        er_lbl = torch.ones(B)
        pr_lbl = torch.ones(B)
        her2_lbl = torch.ones(B)
        sub_lbl = torch.zeros(B).long()

        losses = criterion(preds, er_lbl, pr_lbl, her2_lbl, sub_lbl)
        assert losses["l_final"].item() < 0.5
