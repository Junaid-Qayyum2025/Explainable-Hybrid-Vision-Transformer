"""Unit tests for data pipeline: Macenko normalisation, DSSM, dataset loading."""
import os
import tempfile
from pathlib import Path

import numpy as np
import pytest
import torch


class TestMacenkoNormaliser:
    def test_rgb_image_in_out(self):
        from data.preprocess import MacenkoNormaliser
        norm = MacenkoNormaliser()
        rng = np.random.default_rng(42)
        # Random RGB uint8 image (200x200)
        img = rng.integers(10, 240, (200, 200, 3), dtype=np.uint8)
        out = norm.normalise(img)
        assert out.shape == (200, 200, 3)
        assert out.dtype == np.uint8

    def test_output_range(self):
        from data.preprocess import MacenkoNormaliser
        norm = MacenkoNormaliser()
        rng = np.random.default_rng(0)
        img = rng.integers(50, 220, (100, 100, 3), dtype=np.uint8)
        out = norm.normalise(img)
        assert out.min() >= 0
        assert out.max() <= 255

    def test_grayscale_raises(self):
        from data.preprocess import MacenkoNormaliser
        norm = MacenkoNormaliser()
        grey = np.zeros((64, 64), dtype=np.uint8)
        with pytest.raises(Exception):
            norm.normalise(grey)


class TestDSSM:
    def test_nucleus_density_range(self):
        from data.preprocess import estimate_nucleus_density
        rng = np.random.default_rng(0)
        patch = rng.integers(0, 255, (224, 224, 3), dtype=np.uint8)
        nd = estimate_nucleus_density(patch)
        assert 0.0 <= nd <= 1.0

    def test_dense_tissue_high_nd(self):
        from data.preprocess import estimate_nucleus_density
        # Dark (haematoxylin-rich) patch should have high nucleus density
        dark_patch = np.full((224, 224, 3), 50, dtype=np.uint8)
        nd_dark = estimate_nucleus_density(dark_patch)
        # Light (background) patch
        light_patch = np.full((224, 224, 3), 230, dtype=np.uint8)
        nd_light = estimate_nucleus_density(light_patch)
        assert nd_dark >= nd_light


class TestPatchDataset:
    def _make_csv(self, tmp_dir: str, n: int = 20) -> str:
        import csv
        # Create dummy image files (1x1 pixel PNG)
        try:
            from PIL import Image
        except ImportError:
            pytest.skip("Pillow not installed")

        rows = []
        for i in range(n):
            img_path = os.path.join(tmp_dir, f"patch_{i:04d}.png")
            Image.fromarray(np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)).save(img_path)
            rows.append({
                "filepath": img_path,
                "er_label": i % 2,
                "pr_label": (i + 1) % 2,
                "her2_label": i % 2,
                "subtype_label": i % 4,
            })

        csv_path = os.path.join(tmp_dir, "patches.csv")
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["filepath", "er_label", "pr_label",
                                                    "her2_label", "subtype_label"])
            writer.writeheader()
            writer.writerows(rows)
        return csv_path

    def test_dataset_length(self):
        from src.datasets.patch_dataset import PatchDataset
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = self._make_csv(tmp, n=10)
            ds = PatchDataset(csv_path, split="train")
            assert len(ds) == 10

    def test_dataset_item_keys(self):
        from src.datasets.patch_dataset import PatchDataset
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = self._make_csv(tmp, n=5)
            ds = PatchDataset(csv_path, split="test")
            item = ds[0]
            for key in ["image", "er_label", "pr_label", "her2_label", "subtype_label"]:
                assert key in item, f"Missing key: {key}"

    def test_image_tensor_shape(self):
        from src.datasets.patch_dataset import PatchDataset
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = self._make_csv(tmp, n=3)
            ds = PatchDataset(csv_path, split="test")
            item = ds[0]
            assert item["image"].shape == (3, 224, 224)

    def test_label_types(self):
        from src.datasets.patch_dataset import PatchDataset
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = self._make_csv(tmp, n=5)
            ds = PatchDataset(csv_path, split="test")
            item = ds[0]
            assert item["er_label"].dtype == torch.long or item["er_label"].dtype == torch.float32
            assert item["subtype_label"].dtype in (torch.long, torch.int64)
