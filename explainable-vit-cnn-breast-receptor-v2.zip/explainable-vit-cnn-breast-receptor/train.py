"""
Training script.

Paper hyperparameters:
  Optimizer: Adam (lr=2e-5, beta1=0.9, beta2=0.999, eps=1e-8, wd=1e-4)
  PLIP layers: lr=5e-6
  Scheduler: CosineAnnealingLR (T_max=50, eta_min=1e-7), warmup 5 epochs
  Batch size: 32, Max epochs: 100, Early stopping patience: 15
  Mixed precision: FP16 (PyTorch AMP), Gradient clip: 1.0
  Seed: 42, reported as mean±std across 5 seeds

Usage:
    python train.py --config configs/main_model.yaml
    python train.py --config configs/main_model.yaml --seed 43
    python train.py --config configs/ablation_cnn_only.yaml
"""
import argparse
import os
import time
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
import yaml

# Local imports
from src.models import build_model
from src.losses import MultiTaskReceptorLoss
from src.metrics import ReceptorMetrics
from src.datasets.patch_dataset import build_dataloaders
from src.utils import set_seed, Logger, save_checkpoint, load_checkpoint


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def build_optimizer(model: nn.Module, cfg: dict) -> torch.optim.Optimizer:
    opt_cfg = cfg["optimizer"]
    param_groups = model.get_optimizer_param_groups(cfg)
    return torch.optim.Adam(
        param_groups,
        betas=(opt_cfg["beta1"], opt_cfg["beta2"]),
        eps=opt_cfg["eps"],
    )


def build_scheduler(optimizer: torch.optim.Optimizer, cfg: dict):
    sched_cfg = cfg["scheduler"]
    warmup_epochs = sched_cfg.get("warmup_epochs", 5)

    def lr_lambda(epoch):
        if epoch < warmup_epochs:
            return max(1e-7, epoch / warmup_epochs)
        return 1.0

    warmup = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lr_lambda)
    cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=sched_cfg["T_max"],
        eta_min=sched_cfg["eta_min"],
    )
    return torch.optim.lr_scheduler.SequentialLR(
        optimizer,
        schedulers=[warmup, cosine],
        milestones=[warmup_epochs],
    )


def train_one_epoch(
    model: nn.Module,
    loader,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    scaler: GradScaler,
    device: torch.device,
    cfg: dict,
    epoch: int,
    logger: Logger,
) -> Dict[str, float]:
    model.train()
    metrics = ReceptorMetrics()
    total_loss = 0.0
    n_batches = 0
    grad_clip = cfg["training"].get("grad_clip_norm", 1.0)
    use_amp = cfg["training"].get("mixed_precision", True)

    for step, batch in enumerate(loader):
        images = batch["image"].to(device, non_blocking=True)
        er_label = batch["er_label"].to(device, non_blocking=True)
        pr_label = batch["pr_label"].to(device, non_blocking=True)
        her2_label = batch["her2_label"].to(device, non_blocking=True)
        subtype_label = batch["subtype_label"].to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)

        with autocast(enabled=use_amp):
            preds = model(images)
            losses = loss_fn(preds, er_label, pr_label, her2_label, subtype_label)
            loss = losses["l_final"]

        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        scaler.step(optimizer)
        scaler.update()

        total_loss += loss.item()
        n_batches += 1

        metrics.update(
            preds["er_prob"], preds["pr_prob"], preds["her2_prob"],
            er_label, pr_label, her2_label,
            preds["subtype_logits"], subtype_label,
        )

        global_step = epoch * len(loader) + step
        log_interval = cfg["logging"].get("log_interval", 50)
        if step % log_interval == 0:
            logger.log(
                {"loss": loss.item(), "l_er": losses["l_er"].item(),
                 "l_pr": losses["l_pr"].item(), "l_her2": losses["l_her2"].item()},
                step=global_step,
                prefix="train",
            )

    results = metrics.compute()
    avg_loss = total_loss / max(n_batches, 1)
    return {"loss": avg_loss, **{f"er_{k}": v for k, v in results["er"].items()},
            **{f"pr_{k}": v for k, v in results["pr"].items()},
            **{f"her2_{k}": v for k, v in results["her2"].items()},
            "mean_auc": results["mean_auc"]}


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader,
    loss_fn: nn.Module,
    device: torch.device,
    cfg: dict,
) -> Dict[str, float]:
    model.eval()
    metrics = ReceptorMetrics()
    total_loss = 0.0
    n_batches = 0
    use_amp = cfg["training"].get("mixed_precision", True)

    for batch in loader:
        images = batch["image"].to(device, non_blocking=True)
        er_label = batch["er_label"].to(device, non_blocking=True)
        pr_label = batch["pr_label"].to(device, non_blocking=True)
        her2_label = batch["her2_label"].to(device, non_blocking=True)
        subtype_label = batch["subtype_label"].to(device, non_blocking=True)

        with autocast(enabled=use_amp):
            preds = model(images)
            losses = loss_fn(preds, er_label, pr_label, her2_label, subtype_label)

        total_loss += losses["l_final"].item()
        n_batches += 1
        metrics.update(
            preds["er_prob"], preds["pr_prob"], preds["her2_prob"],
            er_label, pr_label, her2_label,
            preds["subtype_logits"], subtype_label,
        )

    results = metrics.compute()
    return {"loss": total_loss / max(n_batches, 1),
            **{f"er_{k}": v for k, v in results["er"].items()},
            **{f"pr_{k}": v for k, v in results["pr"].items()},
            **{f"her2_{k}": v for k, v in results["her2"].items()},
            "mean_auc": results["mean_auc"]}


def train(cfg: dict, seed: int) -> Dict[str, float]:
    """
    Run one complete training + evaluation for a single seed.
    Returns test metrics.
    """
    cfg_seed = {**cfg}
    cfg_seed["seed"] = seed
    exp_name = f"{cfg['experiment_name']}_seed{seed}"

    set_seed(seed, deterministic=cfg["training"].get("deterministic", True))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n{'='*60}")
    print(f"Experiment: {exp_name}")
    print(f"Device: {device}")
    print(f"Seed: {seed}")
    print(f"{'='*60}")

    # Data
    train_loader, val_loader, test_loader = build_dataloaders(cfg)

    # Model
    model = build_model(cfg).to(device)
    param_counts = model.count_parameters()
    print(f"Parameters: {param_counts}")

    # Loss, optimizer, scheduler
    loss_fn = MultiTaskReceptorLoss(cfg).to(device)
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg)
    scaler = GradScaler(enabled=cfg["training"].get("mixed_precision", True))

    # Logger
    logger = Logger(
        cfg["logging"]["log_dir"],
        exp_name,
        use_tensorboard=cfg["logging"].get("tensorboard", True),
        use_csv=cfg["logging"].get("csv_log", True),
    )

    # Training loop
    best_metric = -float("inf")
    patience_counter = 0
    patience = cfg["training"]["early_stopping_patience"]
    monitor_metric = cfg["training"].get("early_stopping_metric", "val_auc_mean")
    max_epochs = cfg["training"]["max_epochs"]

    for epoch in range(max_epochs):
        t0 = time.time()
        train_metrics = train_one_epoch(
            model, train_loader, optimizer, loss_fn, scaler, device, cfg, epoch, logger
        )
        val_metrics = evaluate(model, val_loader, loss_fn, device, cfg)
        scheduler.step()

        elapsed = time.time() - t0
        print(
            f"Epoch {epoch+1:03d}/{max_epochs} ({elapsed:.1f}s) | "
            f"Train loss: {train_metrics['loss']:.4f}, Mean AUC: {train_metrics['mean_auc']:.4f} | "
            f"Val loss: {val_metrics['loss']:.4f}, Mean AUC: {val_metrics['mean_auc']:.4f} | "
            f"ER: {val_metrics['er_auc']:.4f}, PR: {val_metrics['pr_auc']:.4f}, HER2: {val_metrics['her2_auc']:.4f}"
        )

        logger.log(train_metrics, step=epoch, prefix="train")
        logger.log(val_metrics, step=epoch, prefix="val")

        val_metric = val_metrics["mean_auc"]
        is_best = val_metric > best_metric
        if is_best:
            best_metric = val_metric
            patience_counter = 0
        else:
            patience_counter += 1

        save_checkpoint(
            {
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "scheduler_state_dict": scheduler.state_dict(),
                "best_metric": best_metric,
                "val_metrics": val_metrics,
                "config": cfg,
                "seed": seed,
            },
            checkpoint_dir=cfg["logging"]["checkpoint_dir"],
            experiment_name=exp_name,
            is_best=is_best,
        )

        if patience_counter >= patience:
            print(f"Early stopping at epoch {epoch+1} (patience={patience})")
            break

    # Load best checkpoint for test evaluation
    best_ckpt = str(Path(cfg["logging"]["checkpoint_dir"]) / exp_name / "best.pth")
    if os.path.exists(best_ckpt):
        load_checkpoint(best_ckpt, model, device=str(device))

    test_metrics = evaluate(model, test_loader, loss_fn, device, cfg)
    print(f"\nTest results (seed={seed}):")
    print(f"  ER  AUC={test_metrics['er_auc']:.4f}, Acc={test_metrics['er_accuracy']:.4f}")
    print(f"  PR  AUC={test_metrics['pr_auc']:.4f}, Acc={test_metrics['pr_accuracy']:.4f}")
    print(f"  HER2 AUC={test_metrics['her2_auc']:.4f}, Acc={test_metrics['her2_accuracy']:.4f}")

    logger.log(test_metrics, step=0, prefix="test")
    logger.close()

    return test_metrics


def main():
    parser = argparse.ArgumentParser(description="Train ViT-CNN breast cancer receptor model.")
    parser.add_argument("--config", required=True, help="Path to YAML config file")
    parser.add_argument("--seed", type=int, default=None,
                        help="Override seed (default: use config seeds)")
    args = parser.parse_args()

    cfg = load_config(args.config)

    if args.seed is not None:
        seeds = [args.seed]
    else:
        base_seed = cfg.get("seed", 42)
        num_seeds = cfg.get("num_seeds", 5)
        seeds = list(range(base_seed, base_seed + num_seeds))

    all_metrics = []
    for seed in seeds:
        metrics = train(cfg, seed)
        all_metrics.append(metrics)

    if len(all_metrics) > 1:
        import numpy as np
        print(f"\n{'='*60}")
        print(f"SUMMARY across {len(seeds)} seeds: {seeds}")
        print(f"{'='*60}")
        for key in ["er_auc", "pr_auc", "her2_auc", "er_accuracy", "mean_auc"]:
            vals = [m[key] for m in all_metrics if key in m]
            if vals:
                print(f"  {key}: {np.mean(vals):.4f} ± {np.std(vals):.4f}")


if __name__ == "__main__":
    main()
