"""
DCS-ST baseline: Dual-Channel Spatial-Temporal model.

Paper reference (Table 5 SOTA comparison):
  Li et al. (2023), "DCS-ST: Dual-Channel Spatial-Temporal..."
  IEEE Internet of Things Journal, 2023.
  DOI: [UNVERIFIED — check paper reference list]

This is a reference implementation for comparison purposes.
Exact architecture details are taken from the original paper.
"""
import torch
import torch.nn as nn
import torchvision.models as models


class SpatialChannel(nn.Module):
    """Spatial branch using ResNet-50 for morphological feature extraction."""

    def __init__(self, pretrained: bool = True, out_dim: int = 512):
        super().__init__()
        backbone = models.resnet50(
            weights=models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None
        )
        layers = list(backbone.children())[:-1]  # Remove final FC
        self.encoder = nn.Sequential(*layers)
        self.proj = nn.Linear(2048, out_dim)
        self.norm = nn.LayerNorm(out_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.encoder(x).flatten(1)
        return self.norm(self.proj(feat))


class TemporalChannel(nn.Module):
    """
    Temporal/sequential branch for patch sequence modelling.
    Uses a lightweight Transformer on the spatial features.
    """

    def __init__(self, in_dim: int = 512, num_heads: int = 4, num_layers: int = 2, out_dim: int = 512):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=in_dim, nhead=num_heads, dim_feedforward=in_dim * 4,
            dropout=0.1, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.pool = nn.AdaptiveAvgPool1d(1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 1, in_dim) — single patch
        x = x.unsqueeze(1)
        out = self.transformer(x)  # (B, 1, in_dim)
        return out.squeeze(1)


class DCSST(nn.Module):
    """
    DCS-ST baseline model (Li et al., IEEE IoT J, 2023).
    Dual-channel spatial-temporal architecture for comparison.
    """

    def __init__(self, cfg: dict):
        super().__init__()
        out_dim = 512
        self.spatial = SpatialChannel(pretrained=True, out_dim=out_dim)
        self.temporal = TemporalChannel(in_dim=out_dim, out_dim=out_dim)

        # Fusion
        self.fusion = nn.Sequential(
            nn.Linear(out_dim * 2, out_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
        )

        # Heads
        self.er_head = nn.Linear(out_dim, 1)
        self.pr_head = nn.Linear(out_dim, 1)
        self.her2_head = nn.Linear(out_dim, 1)
        self.subtype_head = nn.Linear(out_dim, 4)

    def forward(self, x: torch.Tensor) -> dict:
        spatial_feat = self.spatial(x)
        temporal_feat = self.temporal(spatial_feat)
        fused = self.fusion(torch.cat([spatial_feat, temporal_feat], dim=-1))
        return {
            "er_prob": torch.sigmoid(self.er_head(fused)).squeeze(-1),
            "pr_prob": torch.sigmoid(self.pr_head(fused)).squeeze(-1),
            "her2_prob": torch.sigmoid(self.her2_head(fused)).squeeze(-1),
            "subtype_logits": self.subtype_head(fused),
        }
