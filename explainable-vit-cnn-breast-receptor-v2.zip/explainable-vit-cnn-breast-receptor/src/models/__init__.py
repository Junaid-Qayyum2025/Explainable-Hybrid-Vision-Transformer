from .vit_cnn_fusion import ViTCNNFusion
from .vit_branch import PLIPViTBranch
from .cnn_branch import ResNet50AttentionBranch
from .cross_attention_fusion import (
    CrossAttentionFusion,
    ConcatMLPFusion,
    AdditiveFusion,
    GatedFusion,
    FiLMFusion,
    MultiStageFusion,
)
from .dssm import DynamicScaleSwitchingModule


def build_model(cfg: dict) -> "ViTCNNFusion":
    """Build the model from config dict."""
    return ViTCNNFusion(cfg)


__all__ = [
    "ViTCNNFusion",
    "PLIPViTBranch",
    "ResNet50AttentionBranch",
    "CrossAttentionFusion",
    "ConcatMLPFusion",
    "AdditiveFusion",
    "GatedFusion",
    "FiLMFusion",
    "MultiStageFusion",
    "DynamicScaleSwitchingModule",
    "build_model",
]
