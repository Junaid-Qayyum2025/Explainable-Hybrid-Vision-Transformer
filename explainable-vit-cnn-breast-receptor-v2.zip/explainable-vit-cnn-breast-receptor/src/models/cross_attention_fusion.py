"""
Cross-attention fusion modules.

Paper Section 3.4 — Bidirectional Cross-Attention Fusion:
  - 8-head bidirectional cross-attention
  - d_model = 1024, head_dim = 128
  - N_v = 196 ViT patch tokens, N_c = 49 CNN spatial tokens
  - Output: 1024-dim cross-attended features
  - Final: [F_vit_cls (768); F_cnn_pool (1024); F_cross (1024)] -> W_fusion -> 1024-dim

Also implements fusion ablation variants (Table 7):
  - ConcatMLPFusion
  - AdditiveFusion
  - GatedFusion
  - FiLMFusion
  - MultiStageFusion
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class CrossAttentionFusion(nn.Module):
    """
    Bidirectional 8-head cross-attention fusion module.

    Paper equations (Section 3.4):
      Attention(Q, K, V) = softmax(QK^T / sqrt(d_k)) * V

    ViT→CNN direction: Q=F_cnn, K=F_vit_tokens, V=F_vit_tokens
    CNN→ViT direction: Q=F_vit_tokens, K=F_cnn_tokens, V=F_cnn_tokens

    Both outputs are pooled and concatenated with input CLS/pool features.
    """

    def __init__(self, cfg: dict):
        super().__init__()
        fusion_cfg = cfg["model"]["fusion"]
        vit_cfg = cfg["model"]["vit"]
        cnn_cfg = cfg["model"]["cnn"]

        self.num_heads = fusion_cfg.get("num_heads", 8)
        self.d_model = fusion_cfg.get("d_model", 1024)
        self.head_dim = fusion_cfg.get("head_dim", 128)
        self.dropout_p = fusion_cfg.get("dropout", 0.20)
        self.fusion_dim = fusion_cfg.get("fusion_dim", 1024)

        self.vit_dim = vit_cfg.get("hidden_dim", 768)
        self.cnn_dim = cnn_cfg.get("projection_dim", 1024)

        assert self.num_heads * self.head_dim == self.d_model, (
            f"num_heads ({self.num_heads}) * head_dim ({self.head_dim}) must == d_model ({self.d_model})"
        )

        # Project ViT tokens to d_model
        self.vit_proj = nn.Linear(self.vit_dim, self.d_model)

        # Cross-attention: ViT attending to CNN (Q from ViT, K/V from CNN)
        self.cross_attn_vit2cnn = nn.MultiheadAttention(
            embed_dim=self.d_model,
            num_heads=self.num_heads,
            dropout=self.dropout_p,
            batch_first=True,
        )

        # Cross-attention: CNN attending to ViT (Q from CNN, K/V from ViT)
        self.cross_attn_cnn2vit = nn.MultiheadAttention(
            embed_dim=self.d_model,
            num_heads=self.num_heads,
            dropout=self.dropout_p,
            batch_first=True,
        )

        # Layer norms
        self.norm_vit = nn.LayerNorm(self.d_model)
        self.norm_cnn = nn.LayerNorm(self.d_model)

        # Pool cross-attended features to single vector
        self.pool = nn.AdaptiveAvgPool1d(1)

        # Fusion projection
        # Input: [F_vit_cls (768), F_cnn_pool (1024), F_cross_vit (1024), F_cross_cnn (1024)] = 3840
        # Implementation concatenates four vectors (3840-d); the manuscript's Eq. 15 sums the two pooled cross-attention outputs (3072-d)
        # [NOT STATED IN PAPER whether CLS and pool are both used or projected first]
        in_fusion_dim = self.vit_dim + self.cnn_dim + self.d_model + self.d_model

        self.fusion_head = nn.Sequential(
            nn.Linear(in_fusion_dim, self.fusion_dim),
            nn.LayerNorm(self.fusion_dim),
            nn.GELU(),
            nn.Dropout(self.dropout_p),
        )

    def forward(
        self,
        vit_cls: torch.Tensor,          # (B, 768)
        vit_tokens: torch.Tensor,        # (B, N_v, 768)
        cnn_pool: torch.Tensor,          # (B, 1024)
        cnn_tokens: torch.Tensor,        # (B, N_c, 1024)
    ) -> torch.Tensor:
        """
        Returns:
            fused: (B, fusion_dim=1024) — final fused representation
        """
        # Project ViT tokens to d_model
        vit_q = self.vit_proj(vit_tokens)   # (B, N_v, 1024)

        # CNN→ViT: CNN tokens attend to ViT tokens
        # Q=cnn_tokens, K=vit_tokens, V=vit_tokens
        cross_cnn, _ = self.cross_attn_cnn2vit(
            query=cnn_tokens,               # (B, N_c, 1024)
            key=vit_q,                      # (B, N_v, 1024)
            value=vit_q,
        )
        cross_cnn = self.norm_cnn(cross_cnn + cnn_tokens)  # Residual
        # Pool over token dimension: (B, 1024)
        F_cross_cnn = cross_cnn.transpose(1, 2)
        F_cross_cnn = self.pool(F_cross_cnn).squeeze(-1)

        # ViT→CNN: ViT tokens attend to CNN tokens
        # Q=vit_tokens, K=cnn_tokens, V=cnn_tokens
        cross_vit, _ = self.cross_attn_vit2cnn(
            query=vit_q,                    # (B, N_v, 1024)
            key=cnn_tokens,                 # (B, N_c, 1024)
            value=cnn_tokens,
        )
        cross_vit = self.norm_vit(cross_vit + vit_q)  # Residual
        # Pool: (B, 1024)
        F_cross_vit = cross_vit.transpose(1, 2)
        F_cross_vit = self.pool(F_cross_vit).squeeze(-1)

        # Concatenate all features
        # [F_vit_cls (768), F_cnn_pool (1024), F_cross_vit (1024), F_cross_cnn (1024)]
        fused_input = torch.cat([vit_cls, cnn_pool, F_cross_vit, F_cross_cnn], dim=-1)
        fused = self.fusion_head(fused_input)  # (B, 1024)

        return fused


class ConcatMLPFusion(nn.Module):
    """Concatenation + MLP fusion (Table 7, row 1)."""

    def __init__(self, cfg: dict):
        super().__init__()
        fusion_cfg = cfg["model"]["fusion"]
        vit_dim = cfg["model"]["vit"]["hidden_dim"]
        cnn_dim = cfg["model"]["cnn"]["projection_dim"]
        d_model = fusion_cfg.get("d_model", 1024)
        dropout_p = fusion_cfg.get("dropout", 0.20)

        in_dim = vit_dim + cnn_dim  # 768 + 1024 = 1792
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, d_model * 2),
            nn.LayerNorm(d_model * 2),
            nn.GELU(),
            nn.Dropout(dropout_p),
            nn.Linear(d_model * 2, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Dropout(dropout_p),
        )

    def forward(self, vit_cls, vit_tokens, cnn_pool, cnn_tokens):
        return self.mlp(torch.cat([vit_cls, cnn_pool], dim=-1))


class AdditiveFusion(nn.Module):
    """Additive (element-wise sum) fusion (Table 7, row 2)."""

    def __init__(self, cfg: dict):
        super().__init__()
        fusion_cfg = cfg["model"]["fusion"]
        vit_dim = cfg["model"]["vit"]["hidden_dim"]
        cnn_dim = cfg["model"]["cnn"]["projection_dim"]
        d_model = fusion_cfg.get("d_model", 1024)
        dropout_p = fusion_cfg.get("dropout", 0.20)

        self.vit_proj = nn.Linear(vit_dim, d_model)
        self.cnn_proj = nn.Linear(cnn_dim, d_model)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout_p)

    def forward(self, vit_cls, vit_tokens, cnn_pool, cnn_tokens):
        v = self.vit_proj(vit_cls)
        c = self.cnn_proj(cnn_pool)
        return self.dropout(self.norm(v + c))


class GatedFusion(nn.Module):
    """Gated fusion (Table 7, row 3)."""

    def __init__(self, cfg: dict):
        super().__init__()
        fusion_cfg = cfg["model"]["fusion"]
        vit_dim = cfg["model"]["vit"]["hidden_dim"]
        cnn_dim = cfg["model"]["cnn"]["projection_dim"]
        d_model = fusion_cfg.get("d_model", 1024)
        dropout_p = fusion_cfg.get("dropout", 0.20)

        self.vit_proj = nn.Linear(vit_dim, d_model)
        self.cnn_proj = nn.Linear(cnn_dim, d_model)
        self.gate = nn.Sequential(
            nn.Linear(vit_dim + cnn_dim, d_model),
            nn.Sigmoid(),
        )
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout_p)

    def forward(self, vit_cls, vit_tokens, cnn_pool, cnn_tokens):
        v = self.vit_proj(vit_cls)
        c = self.cnn_proj(cnn_pool)
        g = self.gate(torch.cat([vit_cls, cnn_pool], dim=-1))
        out = g * v + (1 - g) * c
        return self.dropout(self.norm(out))


class FiLMFusion(nn.Module):
    """Feature-wise Linear Modulation (FiLM) fusion (Table 7, row 4)."""

    def __init__(self, cfg: dict):
        super().__init__()
        fusion_cfg = cfg["model"]["fusion"]
        vit_dim = cfg["model"]["vit"]["hidden_dim"]
        cnn_dim = cfg["model"]["cnn"]["projection_dim"]
        d_model = fusion_cfg.get("d_model", 1024)
        dropout_p = fusion_cfg.get("dropout", 0.20)

        self.cnn_proj = nn.Linear(cnn_dim, d_model)
        # FiLM: gamma and beta generated from ViT features
        self.gamma_net = nn.Linear(vit_dim, d_model)
        self.beta_net = nn.Linear(vit_dim, d_model)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout_p)

    def forward(self, vit_cls, vit_tokens, cnn_pool, cnn_tokens):
        h = self.cnn_proj(cnn_pool)
        gamma = self.gamma_net(vit_cls)
        beta = self.beta_net(vit_cls)
        out = gamma * h + beta
        return self.dropout(self.norm(out))


class MultiStageFusion(nn.Module):
    """Multi-stage progressive fusion (Table 7, row 5)."""

    def __init__(self, cfg: dict):
        super().__init__()
        fusion_cfg = cfg["model"]["fusion"]
        vit_dim = cfg["model"]["vit"]["hidden_dim"]
        cnn_dim = cfg["model"]["cnn"]["projection_dim"]
        d_model = fusion_cfg.get("d_model", 1024)
        dropout_p = fusion_cfg.get("dropout", 0.20)

        # Stage 1: early fusion
        self.stage1 = nn.Sequential(
            nn.Linear(vit_dim + cnn_dim, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Dropout(dropout_p),
        )
        # Stage 2: refinement
        self.stage2 = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Dropout(dropout_p),
        )
        # Stage 3: final projection
        self.stage3 = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
        )

    def forward(self, vit_cls, vit_tokens, cnn_pool, cnn_tokens):
        x = self.stage1(torch.cat([vit_cls, cnn_pool], dim=-1))
        x = self.stage2(x) + x  # Residual
        return self.stage3(x)


FUSION_REGISTRY = {
    "cross_attention": CrossAttentionFusion,
    "concat_mlp": ConcatMLPFusion,
    "additive": AdditiveFusion,
    "gated": GatedFusion,
    "film": FiLMFusion,
    "multistage": MultiStageFusion,
}


def build_fusion(cfg: dict) -> nn.Module:
    fusion_type = cfg["model"]["fusion"]["type"]
    if fusion_type not in FUSION_REGISTRY:
        raise ValueError(f"Unknown fusion type: {fusion_type}. Options: {list(FUSION_REGISTRY.keys())}")
    return FUSION_REGISTRY[fusion_type](cfg)
