"""
Main model: Explainable Hybrid ViT-CNN with Bidirectional Cross-Attention Fusion.

Architecture summary (paper Section 3):
  Input: 224x224 RGB patch (pre-extracted by DSSM + Macenko normalisation)

  ViT Branch:
    PLIP-ViT-Base (12 layers, 12 heads, 768-dim)
    First 6 blocks frozen, last 6 at lr=5e-6
    -> CLS token (768-dim) + 196 patch tokens

  CNN Branch:
    ResNet-50 + spatial attention gates + dilated convolutions
    All layers at lr=2e-5
    -> GAP feature (1024-dim) + 49 spatial tokens

  Cross-Attention Fusion (8-head bidirectional):
    [F_vit_cls; F_cnn_pool; F_cross_vit; F_cross_cnn] -> W_fusion -> 1024-dim

  Classification heads:
    ER head:     Linear(1024, 1) + Sigmoid
    PR head:     Linear(1024, 1) + Sigmoid
    HER2 head:   Linear(1024, 1) + Sigmoid
    Subtype head: Linear(1024, 4) + Softmax (Luminal A/B, HER2-enriched, TNBC)

  MC Dropout: enabled at inference, 30 forward passes (T=30), threshold=0.85

Also implements the following ablation variants via the fusion module:
  - CNNOnly: only CNN branch, no ViT, no cross-attention
  - ViTOnly: only ViT branch, no CNN, no cross-attention
  - ViTCNNFusion with fusion_type in {cross_attention, concat_mlp, additive, gated, film, multistage}
"""
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn

from .vit_branch import PLIPViTBranch
from .cnn_branch import ResNet50AttentionBranch
from .cross_attention_fusion import build_fusion


class ClassificationHeads(nn.Module):
    """Three receptor heads + subtype head, all fed from the 1024-dim fused feature."""

    def __init__(self, in_dim: int = 1024, num_subtype_classes: int = 4, dropout: float = 0.20):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        # Receptor heads (binary, sigmoid)
        self.er_head = nn.Linear(in_dim, 1)
        self.pr_head = nn.Linear(in_dim, 1)
        self.her2_head = nn.Linear(in_dim, 1)
        # Subtype head (4-class)
        self.subtype_head = nn.Linear(in_dim, num_subtype_classes)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        x = self.dropout(x)
        return {
            "er_prob": torch.sigmoid(self.er_head(x)).squeeze(-1),        # (B,)
            "pr_prob": torch.sigmoid(self.pr_head(x)).squeeze(-1),        # (B,)
            "her2_prob": torch.sigmoid(self.her2_head(x)).squeeze(-1),    # (B,)
            "subtype_logits": self.subtype_head(x),                        # (B, 4)
        }


class ViTCNNFusion(nn.Module):
    """
    Full hybrid ViT-CNN model with cross-attention fusion.
    Supports all ablation variants via config.
    """

    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        model_name = cfg["model"]["name"]
        heads_cfg = cfg["model"].get("heads", {})
        fusion_dim = cfg["model"]["fusion"]["fusion_dim"] if "fusion" in cfg["model"] else 1024

        # Build branches based on model variant
        self.use_vit = model_name in ("ViTCNNFusion", "ViTOnly")
        self.use_cnn = model_name in ("ViTCNNFusion", "CNNOnly")

        if self.use_vit:
            self.vit_branch = PLIPViTBranch(cfg)
        if self.use_cnn:
            self.cnn_branch = ResNet50AttentionBranch(cfg)

        # Fusion module
        if model_name == "ViTCNNFusion":
            self.fusion = build_fusion(cfg)
            self._fusion_input_dim = fusion_dim
        elif model_name == "ViTOnly":
            vit_dim = cfg["model"]["vit"]["hidden_dim"]
            self._fusion_input_dim = vit_dim
            self.fusion = nn.Sequential(
                nn.Linear(vit_dim, fusion_dim),
                nn.LayerNorm(fusion_dim),
                nn.GELU(),
                nn.Dropout(heads_cfg.get("receptor_dropout", 0.20)),
            )
        elif model_name == "CNNOnly":
            cnn_proj_dim = cfg["model"]["cnn"]["projection_dim"]
            self._fusion_input_dim = cnn_proj_dim
            self.fusion = nn.Sequential(
                nn.Linear(cnn_proj_dim, fusion_dim),
                nn.LayerNorm(fusion_dim),
                nn.GELU(),
                nn.Dropout(heads_cfg.get("receptor_dropout", 0.20)),
            )
        else:
            raise ValueError(f"Unknown model name: {model_name}")

        self.model_name = model_name

        # Classification heads
        self.heads = ClassificationHeads(
            in_dim=fusion_dim,
            num_subtype_classes=heads_cfg.get("num_subtype_classes", 4),
            dropout=heads_cfg.get("receptor_dropout", 0.20),
        )

        # MC dropout (always enabled; set to eval() to disable during non-MC inference)
        self.mc_dropout = nn.Dropout(p=0.20)

    def forward(
        self,
        x: torch.Tensor,
        return_features: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            x: (B, 3, 224, 224) input patch
            return_features: if True, also return intermediate features

        Returns:
            dict with keys: er_prob, pr_prob, her2_prob, subtype_logits
        """
        vit_cls = None
        vit_tokens = None
        cnn_pool = None
        cnn_tokens = None

        if self.use_vit:
            vit_cls, vit_tokens = self.vit_branch(x)

        if self.use_cnn:
            cnn_pool, cnn_tokens = self.cnn_branch(x)

        # Fuse features
        if self.model_name == "ViTCNNFusion":
            fused = self.fusion(vit_cls, vit_tokens, cnn_pool, cnn_tokens)
        elif self.model_name == "ViTOnly":
            fused = self.fusion(vit_cls)
        elif self.model_name == "CNNOnly":
            fused = self.fusion(cnn_pool)

        preds = self.heads(fused)

        if return_features:
            preds["fused_feature"] = fused
            if vit_cls is not None:
                preds["vit_cls"] = vit_cls
            if cnn_pool is not None:
                preds["cnn_pool"] = cnn_pool

        return preds

    @torch.no_grad()
    def mc_forward(
        self,
        x: torch.Tensor,
        num_passes: int = 30,
    ) -> Dict[str, torch.Tensor]:
        """
        Monte Carlo dropout inference.
        Keeps dropout active for T=30 forward passes.
        Returns mean and variance over passes.
        """
        # Enable dropout for MC passes
        self.train()

        all_er, all_pr, all_her2 = [], [], []
        for _ in range(num_passes):
            with torch.cuda.amp.autocast(enabled=self.cfg["training"].get("mixed_precision", True)):
                preds = self.forward(x)
            all_er.append(preds["er_prob"])
            all_pr.append(preds["pr_prob"])
            all_her2.append(preds["her2_prob"])

        self.eval()

        er_stack = torch.stack(all_er, dim=0)     # (T, B)
        pr_stack = torch.stack(all_pr, dim=0)
        her2_stack = torch.stack(all_her2, dim=0)

        return {
            "er_prob_mean": er_stack.mean(0),
            "er_prob_var": er_stack.var(0),
            "pr_prob_mean": pr_stack.mean(0),
            "pr_prob_var": pr_stack.var(0),
            "her2_prob_mean": her2_stack.mean(0),
            "her2_prob_var": her2_stack.var(0),
        }

    def get_optimizer_param_groups(self, cfg: dict) -> list:
        """Return parameter groups for the optimiser with per-branch learning rates."""
        opt_cfg = cfg["optimizer"]
        base_lr = opt_cfg["lr"]
        plip_lr = opt_cfg.get("plip_lr", 5e-6)
        wd = opt_cfg.get("weight_decay", 1e-4)

        groups = []

        if self.use_vit:
            vit_groups = self.vit_branch.get_trainable_params(base_lr=base_lr, plip_lr=plip_lr)
            for g in vit_groups:
                g["weight_decay"] = wd
            groups.extend(vit_groups)

        if self.use_cnn:
            cnn_groups = self.cnn_branch.get_trainable_params(lr=base_lr)
            for g in cnn_groups:
                g["weight_decay"] = wd
            groups.extend(cnn_groups)

        # Fusion and heads at base LR
        fusion_params = (
            list(self.fusion.parameters()) +
            list(self.heads.parameters())
        )
        groups.append({
            "params": [p for p in fusion_params if p.requires_grad],
            "lr": base_lr,
            "weight_decay": wd,
        })

        return groups

    def count_parameters(self) -> Dict[str, int]:
        """Count parameters per branch (paper Table 11: total 127.4M)."""
        counts = {}
        if self.use_vit:
            counts["vit"] = sum(p.numel() for p in self.vit_branch.parameters())
        if self.use_cnn:
            counts["cnn"] = sum(p.numel() for p in self.cnn_branch.parameters())
        counts["fusion_heads"] = (
            sum(p.numel() for p in self.fusion.parameters()) +
            sum(p.numel() for p in self.heads.parameters())
        )
        counts["total"] = sum(p.numel() for p in self.parameters())
        return counts
