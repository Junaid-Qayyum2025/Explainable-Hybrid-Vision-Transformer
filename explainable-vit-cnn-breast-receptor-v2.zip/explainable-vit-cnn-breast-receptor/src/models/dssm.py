"""
Dynamic Scale-Switching Module (DSSM).

Paper Section 3.1:
  - Estimates nucleus density (ND) for each patch
  - ND > 0.62: dense cellular region -> 224x224 patch extraction
  - ND <= 0.62: architectural region -> 1024x1024 patch extraction (resized to 224x224)
  - Stride: 50% overlap

This module is applied during preprocessing (data/preprocess.py).
For the forward pass during training, patches are already pre-extracted.
This file provides the DSSM class for reference and for dynamic patch
selection if using on-the-fly patch extraction.
"""
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
import cv2


class DynamicScaleSwitchingModule:
    """
    DSSM: selects patch extraction scale based on nucleus density.

    Used in data/preprocess.py and available for on-the-fly inference.
    """

    def __init__(
        self,
        nucleus_density_threshold: float = 0.62,
        patch_size_dense: int = 224,
        patch_size_sparse: int = 1024,
        target_size: int = 224,
        stride_overlap: float = 0.5,
    ):
        self.nd_threshold = nucleus_density_threshold
        self.patch_size_dense = patch_size_dense
        self.patch_size_sparse = patch_size_sparse
        self.target_size = target_size
        self.stride_overlap = stride_overlap

    def estimate_nucleus_density(self, patch: np.ndarray) -> float:
        """
        Estimate nucleus density (ND) for a single RGB patch.

        ND = fraction of pixels classified as nuclei via Otsu thresholding
        on the haematoxylin-like channel (dark intensity in H&E).
        """
        gray = cv2.cvtColor(patch, cv2.COLOR_RGB2GRAY).astype(np.float32)
        # Invert: nuclei are dark (low intensity) -> become high after inversion
        inverted = 255 - gray
        _, nucleus_mask = cv2.threshold(
            inverted.astype(np.uint8), 0, 255,
            cv2.THRESH_BINARY + cv2.THRESH_OTSU
        )
        nd = float(nucleus_mask.sum()) / (255.0 * nucleus_mask.size)
        return nd

    def select_patch_size(self, nd: float) -> int:
        """Return the appropriate patch extraction size given nucleus density."""
        return self.patch_size_dense if nd > self.nd_threshold else self.patch_size_sparse

    def process_patch(self, patch_array: np.ndarray) -> Tuple[np.ndarray, float, int]:
        """
        Process a patch: estimate ND, determine scale.

        Args:
            patch_array: (H, W, 3) RGB numpy array (at dense scale)

        Returns:
            processed_patch: (target_size, target_size, 3) numpy array
            nd: nucleus density value
            used_patch_size: actual patch size selected
        """
        nd = self.estimate_nucleus_density(patch_array)
        used_size = self.select_patch_size(nd)

        if patch_array.shape[0] != self.target_size:
            pil = Image.fromarray(patch_array)
            pil = pil.resize((self.target_size, self.target_size), Image.LANCZOS)
            patch_array = np.array(pil)

        return patch_array, nd, used_size

    def extract_patch_coordinates(
        self,
        slide_width: int,
        slide_height: int,
    ) -> List[Tuple[int, int, int]]:
        """
        Generate (x, y, scan_size) coordinates for patch extraction.

        Uses dense scan size as the primary grid; sparse patches are
        extracted separately when ND is low.

        Returns:
            List of (x, y, scan_size) tuples
        """
        scan_size = self.patch_size_dense
        stride = int(scan_size * (1 - self.stride_overlap))
        coords = []
        for y in range(0, slide_height - scan_size, stride):
            for x in range(0, slide_width - scan_size, stride):
                coords.append((x, y, scan_size))
        return coords
