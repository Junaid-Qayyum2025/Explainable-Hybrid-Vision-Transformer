"""
CNN Branch: ResNet-50 with spatial attention gates and dilated convolutions.

Architecture (paper Section 3.3):
  - ResNet-50 backbone, ImageNet pretrained
  - Spatial attention gates at each residual stage
  - Dilated convolutions in stages 3 and 4 (dilation rates [NOT STATED] — default: 2, 4)
  - All layers fine-tuned at lr=2e-5
  - Dropout = 0.15
  - Output: Global average pooled (2048-dim) -> projected to 1024-dim
             Spatial tokens: 7x7 = 49 tokens (N_c = 49)
"""
from typing import List, Tuple

import torch
import torch.nn as nn
import torchvision.models as models


class SpatialAttentionGate(nn.Module):
    """
    Spatial attention gate applied after a ResNet stage.
    Produces an attention map that reweights the feature map.
    """

    def __init__(self, in_channels: int):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 4, kernel_size=1),
            nn.BatchNorm2d(in_channels // 4),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // 4, 1, kernel_size=1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        attn = self.conv(x)   # (B, 1, H, W)
        return x * attn       # (B, C, H, W)


class ResNet50AttentionBranch(nn.Module):
    """
    ResNet-50 with spatial attention gates and dilated convolutions.

    Implements the CNN branch described in the paper.
    """

    STAGE_CHANNELS = {
        "layer1": 256,
        "layer2": 512,
        "layer3": 1024,
        "layer4": 2048,
    }

    def __init__(self, cfg: dict):
        super().__init__()
        cnn_cfg = cfg["model"]["cnn"]
        self.dropout_p = cnn_cfg.get("dropout", 0.15)
        self.feature_dim = cnn_cfg.get("feature_dim", 2048)
        self.projection_dim = cnn_cfg.get("projection_dim", 1024)
        self.dilated_stages = cnn_cfg.get("dilated_stages", [3, 4])
        self.dilation_rates = cnn_cfg.get("dilation_rates", [2, 4])
        self.use_spatial_attention = cnn_cfg.get("spatial_attention", True)

        # Load pretrained ResNet-50
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.stem = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = self._apply_dilation(resnet.layer3, dilation=self.dilation_rates[0] if 3 in self.dilated_stages else 1)
        self.layer4 = self._apply_dilation(resnet.layer4, dilation=self.dilation_rates[1] if 4 in self.dilated_stages else 1)

        # Spatial attention gates
        if self.use_spatial_attention:
            self.attn1 = SpatialAttentionGate(self.STAGE_CHANNELS["layer1"])
            self.attn2 = SpatialAttentionGate(self.STAGE_CHANNELS["layer2"])
            self.attn3 = SpatialAttentionGate(self.STAGE_CHANNELS["layer3"])
            self.attn4 = SpatialAttentionGate(self.STAGE_CHANNELS["layer4"])

        # Global average pool + projection
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.spatial_pool = nn.AdaptiveAvgPool2d(7)  # Ensures N_c = 49 tokens
        self.dropout = nn.Dropout(p=self.dropout_p)
        self.projection = nn.Sequential(
            nn.Linear(self.feature_dim, self.projection_dim),
            nn.LayerNorm(self.projection_dim),
            nn.GELU(),
        )
        # Token projection to match cross-attention dimension
        self.token_projection = nn.Linear(self.feature_dim, self.projection_dim)

    @staticmethod
    def _apply_dilation(layer: nn.Module, dilation: int) -> nn.Module:
        """Replace stride-2 convolutions with dilated convolutions in a ResNet stage."""
        if dilation == 1:
            return layer
        for name, module in layer.named_modules():
            if isinstance(module, nn.Conv2d) and module.stride == (2, 2):
                module.stride = (1, 1)
                module.dilation = (dilation, dilation)
                module.padding = (dilation, dilation)
            elif isinstance(module, nn.Conv2d) and module.kernel_size == (3, 3):
                module.dilation = (dilation, dilation)
                module.padding = (dilation, dilation)
        return layer

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: (B, 3, 224, 224)

        Returns:
            pooled_feature: (B, projection_dim=1024) — F_cnn_pool
            spatial_tokens: (B, N_c=49, projection_dim=1024) — for cross-attention
        """
        x = self.stem(x)          # (B, 64, 56, 56)
        x = self.layer1(x)        # (B, 256, 56, 56)
        if self.use_spatial_attention:
            x = self.attn1(x)
        x = self.layer2(x)        # (B, 512, 28, 28)
        if self.use_spatial_attention:
            x = self.attn2(x)
        x = self.layer3(x)        # (B, 1024, 14, 14) or (28, 28) with dilation
        if self.use_spatial_attention:
            x = self.attn3(x)
        x = self.layer4(x)        # (B, 2048, 7, 7) or (14, 14) with dilation
        if self.use_spatial_attention:
            x = self.attn4(x)

        # Ensure spatial tokens are 7x7 = 49 (N_c as stated in paper)
        spatial_feat = self.spatial_pool(x)    # (B, 2048, 7, 7)
        spatial_feat = self.dropout(spatial_feat)

        # Global average pool -> 2048-dim
        pooled = self.global_pool(x).flatten(1)  # (B, 2048)
        pooled = self.dropout(pooled)

        # Project to 1024-dim
        F_cnn_pool = self.projection(pooled)     # (B, 1024)

        # Spatial tokens for cross-attention: (B, 49, 1024)
        B, C, H, W = spatial_feat.shape
        tokens = spatial_feat.permute(0, 2, 3, 1).reshape(B, H * W, C)  # (B, 49, 2048)
        tokens = self.token_projection(tokens)                             # (B, 49, 1024)

        return F_cnn_pool, tokens

    def get_trainable_params(self, lr: float) -> List[dict]:
        """All CNN parameters are trainable at base lr."""
        return [{"params": self.parameters(), "lr": lr}]
