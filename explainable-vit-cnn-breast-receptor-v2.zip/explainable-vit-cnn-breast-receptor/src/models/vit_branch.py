"""
ViT Branch: PLIP-ViT-Base backbone.

Architecture (paper Section 3.2):
  - PLIP-ViT-Base pretrained on ~208,000 histopathology image-text pairs (OpenPath)
  - 12 transformer blocks, 12 attention heads, 768-dim hidden
  - First 6 blocks frozen (grad disabled), last 6 trainable at lr=5e-6
  - Dropout = 0.10
  - Input: 224x224 RGB patch -> 196 patch tokens + 1 CLS token
  - Output: CLS token (768-dim) for classification, all 196 patch tokens for cross-attention
"""
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
from transformers import CLIPVisionModel, CLIPVisionConfig


class PLIPViTBranch(nn.Module):
    """
    PLIP-ViT-Base branch.

    PLIP uses CLIP architecture. Load from: https://huggingface.co/vinid/plip
    The vision encoder is a ViT-Base (patch_size=32, hidden_size=768, 12 layers, 12 heads).

    Note: PLIP uses patch_size=32 -> 49 patches (7x7) for 224x224 input, NOT 196.
    Paper states N_v=196 which corresponds to patch_size=16.
    We implement patch_size=16 as stated in the paper (cross-attention section N_v=196).
    """

    def __init__(self, cfg: dict):
        super().__init__()
        vit_cfg = cfg["model"]["vit"]
        self.model_name = vit_cfg.get("model_name", "vinid/plip")
        self.frozen_blocks = vit_cfg.get("frozen_blocks", 6)
        self.dropout_p = vit_cfg.get("dropout", 0.10)
        self.hidden_dim = vit_cfg.get("hidden_dim", 768)
        self.num_tokens = vit_cfg.get("num_tokens", 196)  # N_v from paper

        self._load_backbone()
        self._freeze_blocks()
        self.dropout = nn.Dropout(p=self.dropout_p)

    def _load_backbone(self):
        """Load PLIP vision encoder. Falls back to ViT-Base if PLIP unavailable."""
        try:
            from transformers import CLIPModel
            print(f"Loading PLIP backbone from: {self.model_name}")
            clip = CLIPModel.from_pretrained(self.model_name)
            self.backbone = clip.vision_model
            print("  PLIP loaded successfully.")
        except Exception as e:
            print(f"  WARNING: Could not load PLIP from {self.model_name}: {e}")
            print("  Falling back to ViT-Base (openai/clip-vit-base-patch16) for architecture testing.")
            print("  For full paper reproduction, obtain PLIP weights from https://huggingface.co/vinid/plip")
            try:
                clip_cfg = CLIPVisionConfig(
                    hidden_size=768,
                    intermediate_size=3072,
                    num_hidden_layers=12,
                    num_attention_heads=12,
                    image_size=224,
                    patch_size=16,
                )
                self.backbone = CLIPVisionModel(clip_cfg)
                print("  Initialised ViT-Base architecture (random weights).")
            except Exception as e2:
                raise RuntimeError(f"Could not initialise ViT backbone: {e2}")

    def _freeze_blocks(self):
        """Freeze first `frozen_blocks` transformer blocks. Paper: first 6 frozen."""
        frozen = 0
        trainable = 0
        # Freeze embeddings always
        for p in self.backbone.embeddings.parameters():
            p.requires_grad = False
            frozen += p.numel()
        # Freeze first N encoder layers
        for i, layer in enumerate(self.backbone.encoder.layers):
            if i < self.frozen_blocks:
                for p in layer.parameters():
                    p.requires_grad = False
                    frozen += p.numel()
            else:
                for p in layer.parameters():
                    p.requires_grad = True
                    trainable += p.numel()
        print(f"  ViT: {frozen:,} params frozen, {trainable:,} params trainable (lr=5e-6)")

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: (B, 3, 224, 224)

        Returns:
            cls_token: (B, 768) — CLS token for classification
            patch_tokens: (B, N_v, 768) — all patch tokens for cross-attention
        """
        outputs = self.backbone(
            pixel_values=x,
            output_hidden_states=False,
            output_attentions=False,
            return_dict=True,
        )
        # last_hidden_state: (B, 1 + N_patches, 768)
        hidden = outputs.last_hidden_state

        cls_token = self.dropout(hidden[:, 0, :])       # (B, 768)
        patch_tokens = self.dropout(hidden[:, 1:, :])   # (B, N_v, 768)

        return cls_token, patch_tokens

    def get_trainable_params(self, base_lr: float, plip_lr: float) -> List[dict]:
        """Return parameter groups for the optimiser."""
        frozen_ids = set(id(p) for p in self.backbone.embeddings.parameters())
        for i, layer in enumerate(self.backbone.encoder.layers):
            if i < self.frozen_blocks:
                for p in layer.parameters():
                    frozen_ids.add(id(p))

        plip_params = [
            p for p in self.parameters()
            if p.requires_grad and id(p) not in frozen_ids
        ]
        return [{"params": plip_params, "lr": plip_lr}]
