"""Checkpoint save/load utilities."""
import os
from pathlib import Path
from typing import Optional

import torch


def save_checkpoint(
    state: dict,
    checkpoint_dir: str,
    experiment_name: str,
    is_best: bool = False,
    epoch: Optional[int] = None,
) -> str:
    """
    Save model checkpoint.

    Args:
        state: dict containing model, optimizer, scheduler, epoch, metrics, config
        checkpoint_dir: directory for checkpoints
        experiment_name: name prefix
        is_best: also save as best.pth if True
        epoch: epoch number (appended to filename)

    Returns:
        path to saved checkpoint
    """
    save_dir = Path(checkpoint_dir) / experiment_name
    save_dir.mkdir(parents=True, exist_ok=True)

    fname = "last.pth" if epoch is None else f"epoch_{epoch:04d}.pth"
    path = str(save_dir / fname)
    torch.save(state, path)

    if is_best:
        best_path = str(save_dir / "best.pth")
        torch.save(state, best_path)
        print(f"  Best checkpoint: {best_path}")

    return path


def load_checkpoint(
    path: str,
    model: torch.nn.Module,
    optimizer: Optional[torch.optim.Optimizer] = None,
    scheduler=None,
    device: str = "cpu",
) -> dict:
    """
    Load a checkpoint.

    Returns:
        state dict (epoch, metrics, config, etc.)
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Checkpoint not found: {path}")

    checkpoint = torch.load(path, map_location=device)

    if "model_state_dict" in checkpoint:
        model.load_state_dict(checkpoint["model_state_dict"])
    else:
        model.load_state_dict(checkpoint)

    if optimizer and "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

    if scheduler and "scheduler_state_dict" in checkpoint:
        scheduler.load_state_dict(checkpoint["scheduler_state_dict"])

    print(f"Loaded checkpoint: {path}")
    if "epoch" in checkpoint:
        print(f"  Epoch: {checkpoint['epoch']}")
    if "best_metric" in checkpoint:
        print(f"  Best metric: {checkpoint['best_metric']:.4f}")

    return checkpoint
