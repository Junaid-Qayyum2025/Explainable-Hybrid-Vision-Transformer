"""
Deterministic seeding.

Paper: random seed = 42, results reported as mean±std across 5 seeds.
"""
import os
import random

import numpy as np
import torch


def set_seed(seed: int = 42, deterministic: bool = True) -> None:
    """
    Set all random seeds for full reproducibility.

    Args:
        seed: random seed (paper default: 42)
        deterministic: enable torch deterministic mode
    """
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
        try:
            torch.use_deterministic_algorithms(True)
        except Exception:
            pass  # Not available in all PyTorch versions
    else:
        torch.backends.cudnn.benchmark = True
