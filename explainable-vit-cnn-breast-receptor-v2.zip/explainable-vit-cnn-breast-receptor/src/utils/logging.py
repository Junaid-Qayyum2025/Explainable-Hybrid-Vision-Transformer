"""Logging utilities: CSV log and TensorBoard."""
import csv
import os
from pathlib import Path
from typing import Dict, Optional

try:
    from torch.utils.tensorboard import SummaryWriter
    TENSORBOARD_AVAILABLE = True
except ImportError:
    TENSORBOARD_AVAILABLE = False


class Logger:
    """Logs metrics to CSV and optionally TensorBoard."""

    def __init__(
        self,
        log_dir: str,
        experiment_name: str,
        use_tensorboard: bool = True,
        use_csv: bool = True,
    ):
        self.log_dir = Path(log_dir) / experiment_name
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.experiment_name = experiment_name

        self.csv_path = self.log_dir / "metrics.csv"
        self._csv_file = None
        self._csv_writer = None
        self._csv_fields = None
        self.use_csv = use_csv

        self.writer = None
        if use_tensorboard and TENSORBOARD_AVAILABLE:
            tb_dir = self.log_dir / "tensorboard"
            tb_dir.mkdir(exist_ok=True)
            self.writer = SummaryWriter(log_dir=str(tb_dir))
        elif use_tensorboard:
            print("WARNING: TensorBoard not available. Install tensorboard for TB logging.")

    def log(self, metrics: Dict[str, float], step: int, prefix: str = "") -> None:
        """Log a dict of metrics at a given step."""
        prefixed = {f"{prefix}/{k}" if prefix else k: v for k, v in metrics.items()}
        prefixed["step"] = step

        # TensorBoard
        if self.writer:
            for k, v in prefixed.items():
                if k != "step" and isinstance(v, (int, float)):
                    self.writer.add_scalar(k, v, step)

        # CSV
        if self.use_csv:
            if self._csv_writer is None or self._csv_fields != list(prefixed.keys()):
                self._csv_fields = list(prefixed.keys())
                mode = "a" if self.csv_path.exists() and self._csv_writer is not None else "w"
                if self._csv_file:
                    self._csv_file.close()
                self._csv_file = open(self.csv_path, mode, newline="")
                self._csv_writer = csv.DictWriter(self._csv_file, fieldnames=self._csv_fields)
                if mode == "w":
                    self._csv_writer.writeheader()
            self._csv_writer.writerow(prefixed)
            self._csv_file.flush()

    def close(self) -> None:
        if self._csv_file:
            self._csv_file.close()
        if self.writer:
            self.writer.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
