"""
Patch-level PyTorch Dataset for pre-extracted 224x224 patches.

Used for both training (patch-level batches) and TCGA-BRCA / BreaKHis benchmarks.
"""
import os
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms


class PatchDataset(Dataset):
    """
    Dataset of pre-extracted 224x224 patches with receptor status labels.

    CSV schema:
        filepath     : absolute or relative path to patch PNG
        er_label     : int (0 or 1)
        pr_label     : int (0 or 1)
        her2_label   : int (0 or 1)
        subtype_label: int (0=Luminal A, 1=Luminal B, 2=HER2-enriched, 3=TNBC)
        slide_id     : str
        patient_id   : str
    """

    SUBTYPE_MAP = {
        "luminal_a": 0,
        "luminal a": 0,
        "luminal_b": 1,
        "luminal b": 1,
        "her2-enriched": 2,
        "her2_enriched": 2,
        "tnbc": 3,
        "triple_negative": 3,
    }

    def __init__(
        self,
        csv_path: str,
        data_root: Optional[str] = None,
        transform: Optional[Callable] = None,
        is_train: bool = False,
    ):
        self.df = pd.read_csv(csv_path)
        self.data_root = data_root
        self.is_train = is_train
        self.transform = transform or self._default_transform(is_train)
        self._validate()

    def _validate(self):
        required = ["filepath", "er_label", "pr_label", "her2_label"]
        missing = [c for c in required if c not in self.df.columns]
        if missing:
            raise ValueError(f"CSV missing columns: {missing}")
        if "subtype_label" not in self.df.columns:
            self.df["subtype_label"] = -1  # Unknown

    @staticmethod
    def _default_transform(is_train: bool) -> Callable:
        """
        Augmentations — paper does not specify augmentation details.
        [NOT STATED IN PAPER] Using standard histopathology augmentations.
        """
        mean = [0.485, 0.456, 0.406]
        std = [0.229, 0.224, 0.225]

        if is_train:
            return transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomVerticalFlip(p=0.5),
                transforms.RandomRotation(degrees=90),
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1, hue=0.05),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])
        else:
            return transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict:
        row = self.df.iloc[idx]

        fpath = str(row["filepath"])
        if self.data_root and not os.path.isabs(fpath):
            fpath = os.path.join(self.data_root, fpath)

        img = Image.open(fpath).convert("RGB")
        img_tensor = self.transform(img)

        return {
            "image": img_tensor,
            "er_label": torch.tensor(int(row["er_label"]), dtype=torch.float32),
            "pr_label": torch.tensor(int(row["pr_label"]), dtype=torch.float32),
            "her2_label": torch.tensor(int(row["her2_label"]), dtype=torch.float32),
            "subtype_label": torch.tensor(int(row["subtype_label"]), dtype=torch.long),
            "slide_id": str(row.get("slide_id", "")),
            "patient_id": str(row.get("patient_id", "")),
            "filepath": fpath,
        }


def build_dataloaders(
    cfg: dict,
    transform_train: Optional[Callable] = None,
    transform_val: Optional[Callable] = None,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Build train/val/test DataLoaders from config.
    """
    splits_dir = cfg["data"]["splits_dir"]
    data_root = cfg["data"].get("data_root", None)
    batch_size = cfg["training"]["batch_size"]
    num_workers = cfg["data"].get("num_workers", 4)
    pin_memory = cfg["data"].get("pin_memory", True)

    train_csv = os.path.join(splits_dir, cfg["data"]["train_split"])
    val_csv = os.path.join(splits_dir, cfg["data"]["val_split"])
    test_csv = os.path.join(splits_dir, cfg["data"]["test_split"])

    train_ds = PatchDataset(train_csv, data_root=data_root, transform=transform_train, is_train=True)
    val_ds = PatchDataset(val_csv, data_root=data_root, transform=transform_val, is_train=False)
    test_ds = PatchDataset(test_csv, data_root=data_root, transform=transform_val, is_train=False)

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=pin_memory, drop_last=True
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=pin_memory
    )
    test_loader = DataLoader(
        test_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=pin_memory
    )

    print(f"Dataset sizes — Train: {len(train_ds)}, Val: {len(val_ds)}, Test: {len(test_ds)}")
    return train_loader, val_loader, test_loader
