"""
WSI-level PyTorch Dataset.

Aggregates patch predictions to WSI-level using max-pooling over patch probabilities
(majority-vote / probability averaging at inference).
"""
import os
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms


class WSIDataset(Dataset):
    """
    WSI-level dataset: returns a bag of patches for each WSI.

    CSV schema:
        slide_id     : str (unique WSI identifier)
        patient_id   : str
        patch_dir    : path to directory containing pre-extracted patches for this WSI
        er_label     : int (0/1)
        pr_label     : int (0/1)
        her2_label   : int (0/1)
        subtype_label: int (0-3)
        institution  : str (for multi-institutional experiments)
    """

    def __init__(
        self,
        csv_path: str,
        data_root: Optional[str] = None,
        transform: Optional[Callable] = None,
        max_patches: int = 100,
        is_train: bool = False,
    ):
        self.df = pd.read_csv(csv_path)
        self.data_root = data_root
        self.max_patches = max_patches
        self.is_train = is_train
        self.transform = transform or self._default_transform(is_train)
        self._validate()

    def _validate(self):
        required = ["slide_id", "er_label", "pr_label", "her2_label"]
        missing = [c for c in required if c not in self.df.columns]
        if missing:
            raise ValueError(f"CSV missing columns: {missing}")
        if "subtype_label" not in self.df.columns:
            self.df["subtype_label"] = -1

    @staticmethod
    def _default_transform(is_train: bool) -> Callable:
        mean = [0.485, 0.456, 0.406]
        std = [0.229, 0.224, 0.225]
        if is_train:
            return transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomVerticalFlip(p=0.5),
                transforms.RandomRotation(degrees=90),
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1, hue=0.05),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])
        else:
            return transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])

    def _get_patch_paths(self, row) -> List[str]:
        """Find all patches for this WSI."""
        if "patch_dir" in row and pd.notna(row["patch_dir"]):
            patch_dir = str(row["patch_dir"])
            if self.data_root and not os.path.isabs(patch_dir):
                patch_dir = os.path.join(self.data_root, patch_dir)
            return sorted([
                str(p) for p in Path(patch_dir).glob("*.png")
            ])

        # Fallback: look for slide_id subdirectory
        if self.data_root:
            slide_dir = os.path.join(self.data_root, "patches", str(row["slide_id"]))
            if os.path.isdir(slide_dir):
                return sorted([str(p) for p in Path(slide_dir).glob("*.png")])

        return []

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict:
        row = self.df.iloc[idx]
        patch_paths = self._get_patch_paths(row)

        if not patch_paths:
            # Return zero tensor if no patches found (graceful degradation)
            patches = torch.zeros(1, 3, 224, 224)
        else:
            # Limit and optionally shuffle patches
            if self.is_train and len(patch_paths) > self.max_patches:
                import random
                patch_paths = random.sample(patch_paths, self.max_patches)
            else:
                patch_paths = patch_paths[:self.max_patches]

            imgs = []
            for p in patch_paths:
                try:
                    img = Image.open(p).convert("RGB")
                    imgs.append(self.transform(img))
                except Exception:
                    continue
            patches = torch.stack(imgs) if imgs else torch.zeros(1, 3, 224, 224)

        return {
            "patches": patches,            # (N_patches, 3, 224, 224)
            "n_patches": torch.tensor(len(patches)),
            "er_label": torch.tensor(int(row["er_label"]), dtype=torch.float32),
            "pr_label": torch.tensor(int(row["pr_label"]), dtype=torch.float32),
            "her2_label": torch.tensor(int(row["her2_label"]), dtype=torch.float32),
            "subtype_label": torch.tensor(int(row["subtype_label"]), dtype=torch.long),
            "slide_id": str(row["slide_id"]),
            "patient_id": str(row.get("patient_id", "")),
            "institution": str(row.get("institution", "unknown")),
        }


def wsi_collate_fn(batch: List[Dict]) -> Dict:
    """Custom collate for variable-length patch bags."""
    max_patches = max(item["patches"].shape[0] for item in batch)
    padded_patches = []
    patch_masks = []

    for item in batch:
        n = item["patches"].shape[0]
        pad = max_patches - n
        if pad > 0:
            padded = torch.cat([
                item["patches"],
                torch.zeros(pad, *item["patches"].shape[1:])
            ], dim=0)
        else:
            padded = item["patches"]
        padded_patches.append(padded)

        mask = torch.zeros(max_patches, dtype=torch.bool)
        mask[:n] = True
        patch_masks.append(mask)

    return {
        "patches": torch.stack(padded_patches),           # (B, max_N, 3, 224, 224)
        "patch_mask": torch.stack(patch_masks),           # (B, max_N) True=valid
        "n_patches": torch.stack([item["n_patches"] for item in batch]),
        "er_label": torch.stack([item["er_label"] for item in batch]),
        "pr_label": torch.stack([item["pr_label"] for item in batch]),
        "her2_label": torch.stack([item["her2_label"] for item in batch]),
        "subtype_label": torch.stack([item["subtype_label"] for item in batch]),
        "slide_id": [item["slide_id"] for item in batch],
        "patient_id": [item["patient_id"] for item in batch],
        "institution": [item["institution"] for item in batch],
    }
