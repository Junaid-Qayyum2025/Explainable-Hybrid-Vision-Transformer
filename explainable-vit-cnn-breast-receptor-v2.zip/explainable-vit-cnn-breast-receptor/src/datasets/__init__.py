from .wsi_dataset import WSIDataset
from .patch_dataset import PatchDataset

__all__ = ["WSIDataset", "PatchDataset"]
