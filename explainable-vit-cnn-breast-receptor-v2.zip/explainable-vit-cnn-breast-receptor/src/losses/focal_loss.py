"""
Focal Loss implementation.

Paper equation (Section 3.5):
  L_focal(y, p) = -alpha_t * (1 - p_t)^gamma * log(p_t)
  where:
    p_t = p      if y == 1
    p_t = 1 - p  if y == 0
    alpha_t = alpha    if y == 1
    alpha_t = 1-alpha  if y == 0

Paper hyperparameters:
  gamma = 2.0  [NOT STATED — using standard focal loss default]
  alpha = 0.25 [NOT STATED — using standard focal loss default]

Reference: Lin et al., "Focal Loss for Dense Object Detection", ICCV 2017.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    """
    Binary focal loss for receptor status prediction.

    Args:
        gamma: focusing parameter (paper default: 2.0)
        alpha: class balance weight for positive class (paper default: 0.25)
        reduction: 'mean' or 'sum' or 'none'
    """

    def __init__(self, gamma: float = 2.0, alpha: float = 0.25, reduction: str = "mean"):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Args:
            pred: (B,) predicted probabilities in [0, 1] (after sigmoid)
            target: (B,) binary labels {0, 1}

        Returns:
            Focal loss scalar
        """
        # Clamp for numerical stability
        pred = pred.clamp(min=1e-7, max=1 - 1e-7)

        # p_t: probability of the true class
        p_t = pred * target + (1 - pred) * (1 - target)

        # alpha_t: weight for the true class
        alpha_t = self.alpha * target + (1 - self.alpha) * (1 - target)

        # Focal modulation
        focal_weight = (1 - p_t) ** self.gamma

        # Log probability
        log_p_t = torch.log(p_t)

        loss = -alpha_t * focal_weight * log_p_t

        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss
