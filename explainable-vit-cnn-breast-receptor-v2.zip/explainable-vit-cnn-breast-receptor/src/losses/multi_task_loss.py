"""
Multi-task receptor loss.

Paper equations (Section 3.5):
  L_total = w_ER * L_ER + w_PR * L_PR + w_HER2 * L_HER2
  L_final = L_total + 0.20 * L_subtype

  w_ER   = 0.40
  w_PR   = 0.30
  w_HER2 = 0.30
  w_subtype = 0.20

  L_ER, L_PR, L_HER2: focal loss (binary)
  L_subtype: cross-entropy (4-class)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .focal_loss import FocalLoss


class MultiTaskReceptorLoss(nn.Module):
    """
    Multi-task loss combining focal loss for 3 receptor tasks and
    cross-entropy for subtype classification.
    """

    def __init__(self, cfg: dict):
        super().__init__()
        loss_cfg = cfg["loss"]
        self.w_er = loss_cfg.get("weight_er", 0.40)
        self.w_pr = loss_cfg.get("weight_pr", 0.30)
        self.w_her2 = loss_cfg.get("weight_her2", 0.30)
        self.w_subtype = loss_cfg.get("weight_subtype", 0.20)

        gamma = loss_cfg.get("focal_gamma", 2.0)
        alpha = loss_cfg.get("focal_alpha", 0.25)

        if loss_cfg.get("receptor_loss", "focal") == "focal":
            self.receptor_loss_fn = FocalLoss(gamma=gamma, alpha=alpha, reduction="mean")
        else:
            # Fallback to BCE
            self.receptor_loss_fn = nn.BCELoss()

        self.subtype_loss_fn = nn.CrossEntropyLoss(ignore_index=-1)

    def forward(
        self,
        preds: dict,
        er_label: torch.Tensor,
        pr_label: torch.Tensor,
        her2_label: torch.Tensor,
        subtype_label: torch.Tensor,
    ) -> dict:
        """
        Args:
            preds: dict with er_prob, pr_prob, her2_prob, subtype_logits
            er_label: (B,) float {0,1}
            pr_label: (B,) float {0,1}
            her2_label: (B,) float {0,1}
            subtype_label: (B,) long {0,1,2,3} or -1 if unknown

        Returns:
            dict with l_final, l_total, l_er, l_pr, l_her2, l_subtype
        """
        l_er = self.receptor_loss_fn(preds["er_prob"], er_label)
        l_pr = self.receptor_loss_fn(preds["pr_prob"], pr_label)
        l_her2 = self.receptor_loss_fn(preds["her2_prob"], her2_label)

        l_total = self.w_er * l_er + self.w_pr * l_pr + self.w_her2 * l_her2

        l_subtype = torch.tensor(0.0, device=er_label.device)
        if (subtype_label != -1).any():
            l_subtype = self.subtype_loss_fn(preds["subtype_logits"], subtype_label)

        l_final = l_total + self.w_subtype * l_subtype

        return {
            "l_final": l_final,
            "l_total": l_total,
            "l_er": l_er,
            "l_pr": l_pr,
            "l_her2": l_her2,
            "l_subtype": l_subtype,
        }
