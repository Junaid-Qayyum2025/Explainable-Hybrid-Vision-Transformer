"""
Evaluation metrics for receptor status prediction.

Paper Section 4 (Evaluation Metrics):
  - AUROC (trapezoidal rule, DeLong's method)
  - Accuracy
  - Sensitivity (Recall)
  - Specificity
  - PPV (Precision)
  - NPV
  - F1-score (macro)
  - MCC
  - Brier Score
  - ECE (10 bins)
  - MCE

All receptor metrics reported per-class (ER, PR, HER2) as mean±std across 5 seeds.
"""
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)


def compute_roc_auc(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """AUROC using trapezoidal rule (sklearn default, equivalent to DeLong for single threshold)."""
    if len(np.unique(y_true)) < 2:
        return float("nan")
    return roc_auc_score(y_true, y_prob)


def compute_sensitivity_specificity(
    y_true: np.ndarray, y_pred: np.ndarray
) -> Tuple[float, float]:
    """Sensitivity (recall) and specificity from confusion matrix."""
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    sensitivity = tp / (tp + fn + 1e-8)
    specificity = tn / (tn + fp + 1e-8)
    return float(sensitivity), float(specificity)


def compute_ppv_npv(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float]:
    """Positive and Negative Predictive Value."""
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    ppv = tp / (tp + fp + 1e-8)
    npv = tn / (tn + fn + 1e-8)
    return float(ppv), float(npv)


def compute_mcc(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Matthews Correlation Coefficient."""
    return float(matthews_corrcoef(y_true, y_pred))


def compute_brier_score(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Brier Score: (1/N) sum (p_i - y_i)^2."""
    return float(np.mean((y_prob - y_true) ** 2))


def compute_ece(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
) -> Tuple[float, float]:
    """
    Expected Calibration Error (ECE) and Maximum Calibration Error (MCE).

    ECE = sum_m (|B_m| / N) * |acc(B_m) - conf(B_m)|
    MCE = max_m |acc(B_m) - conf(B_m)|

    Returns:
        ece: Expected Calibration Error (fraction, multiply by 100 for %)
        mce: Maximum Calibration Error (fraction)
    """
    bin_boundaries = np.linspace(0, 1, n_bins + 1)
    n = len(y_true)
    ece = 0.0
    mce = 0.0

    for i in range(n_bins):
        lo, hi = bin_boundaries[i], bin_boundaries[i + 1]
        mask = (y_prob >= lo) & (y_prob < hi)
        if not mask.any():
            continue
        acc = y_true[mask].mean()
        conf = y_prob[mask].mean()
        gap = abs(acc - conf)
        ece += (mask.sum() / n) * gap
        mce = max(mce, gap)

    return float(ece), float(mce)


def compute_receptor_metrics(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    threshold: float = 0.5,
) -> Dict[str, float]:
    """
    Compute all paper metrics for a single binary receptor task.
    """
    y_pred = (y_prob >= threshold).astype(int)

    auc = compute_roc_auc(y_true, y_prob)
    acc = accuracy_score(y_true, y_pred)
    sens, spec = compute_sensitivity_specificity(y_true, y_pred)
    ppv, npv = compute_ppv_npv(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    mcc = compute_mcc(y_true, y_pred)
    brier = compute_brier_score(y_true, y_prob)
    ece, mce = compute_ece(y_true, y_prob)

    return {
        "auc": auc,
        "accuracy": acc,
        "sensitivity": sens,
        "specificity": spec,
        "ppv": ppv,
        "npv": npv,
        "f1": f1,
        "mcc": mcc,
        "brier": brier,
        "ece": ece * 100,   # Report as percentage
        "mce": mce * 100,
    }


def compute_all_metrics(
    er_true: np.ndarray,
    er_prob: np.ndarray,
    pr_true: np.ndarray,
    pr_prob: np.ndarray,
    her2_true: np.ndarray,
    her2_prob: np.ndarray,
    subtype_true: Optional[np.ndarray] = None,
    subtype_pred: Optional[np.ndarray] = None,
    threshold: float = 0.5,
) -> Dict[str, Dict[str, float]]:
    """Compute all paper metrics for all three receptor tasks."""
    results = {
        "er": compute_receptor_metrics(er_true, er_prob, threshold),
        "pr": compute_receptor_metrics(pr_true, pr_prob, threshold),
        "her2": compute_receptor_metrics(her2_true, her2_prob, threshold),
    }

    if subtype_true is not None and subtype_pred is not None:
        valid = subtype_true != -1
        if valid.any():
            st = subtype_true[valid]
            sp = subtype_pred[valid]
            results["subtype"] = {
                "accuracy": float(accuracy_score(st, sp)),
                "f1_macro": float(f1_score(st, sp, average="macro", zero_division=0)),
                "f1_per_class": f1_score(st, sp, average=None, zero_division=0).tolist(),
            }

    # Mean AUC across receptors (used for early stopping)
    results["mean_auc"] = np.nanmean([
        results["er"]["auc"],
        results["pr"]["auc"],
        results["her2"]["auc"],
    ]).item()

    return results


class ReceptorMetrics:
    """
    Accumulator for batch-level predictions, computing full metrics at the end.

    Usage:
        metrics = ReceptorMetrics()
        for batch in loader:
            metrics.update(er_prob, pr_prob, her2_prob, er_label, pr_label, her2_label)
        results = metrics.compute()
        metrics.reset()
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self._er_probs = []
        self._pr_probs = []
        self._her2_probs = []
        self._er_true = []
        self._pr_true = []
        self._her2_true = []
        self._subtype_pred = []
        self._subtype_true = []

    def update(
        self,
        er_prob: torch.Tensor,
        pr_prob: torch.Tensor,
        her2_prob: torch.Tensor,
        er_label: torch.Tensor,
        pr_label: torch.Tensor,
        her2_label: torch.Tensor,
        subtype_logits: Optional[torch.Tensor] = None,
        subtype_label: Optional[torch.Tensor] = None,
    ):
        self._er_probs.append(er_prob.detach().cpu().numpy())
        self._pr_probs.append(pr_prob.detach().cpu().numpy())
        self._her2_probs.append(her2_prob.detach().cpu().numpy())
        self._er_true.append(er_label.detach().cpu().numpy())
        self._pr_true.append(pr_label.detach().cpu().numpy())
        self._her2_true.append(her2_label.detach().cpu().numpy())

        if subtype_logits is not None and subtype_label is not None:
            subtype_p = subtype_logits.argmax(dim=-1).detach().cpu().numpy()
            self._subtype_pred.append(subtype_p)
            self._subtype_true.append(subtype_label.detach().cpu().numpy())

    def compute(self) -> Dict:
        er_prob = np.concatenate(self._er_probs)
        pr_prob = np.concatenate(self._pr_probs)
        her2_prob = np.concatenate(self._her2_probs)
        er_true = np.concatenate(self._er_true).astype(int)
        pr_true = np.concatenate(self._pr_true).astype(int)
        her2_true = np.concatenate(self._her2_true).astype(int)

        subtype_true = np.concatenate(self._subtype_true) if self._subtype_true else None
        subtype_pred = np.concatenate(self._subtype_pred) if self._subtype_pred else None

        return compute_all_metrics(
            er_true, er_prob,
            pr_true, pr_prob,
            her2_true, her2_prob,
            subtype_true, subtype_pred,
        )
