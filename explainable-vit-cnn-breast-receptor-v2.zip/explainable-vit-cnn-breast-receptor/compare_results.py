"""
Compare reproduced results against paper-reported expected values.

Flags any metric that differs by more than the specified tolerance.
Tolerance defaults: AUC ±0.005, Accuracy ±0.010, ECE ±0.5 pp.

Usage:
    python compare_results.py
    python compare_results.py --expected results/expected/ --reproduced results/reproduced/
    python compare_results.py --tolerance_auc 0.01
"""
import argparse
import json
import os
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np


PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
WARN = "\033[93mWARN\033[0m"
SKIP = "\033[94mSKIP\033[0m"


def load_json(path: str) -> Optional[dict]:
    if not Path(path).exists():
        return None
    with open(path) as f:
        return json.load(f)


def parse_mean_std(s: str) -> Tuple[float, float]:
    """Parse '0.9670 ± 0.0120' into (mean, std)."""
    if "±" in s:
        parts = s.split("±")
        return float(parts[0].strip()), float(parts[1].strip())
    return float(s.strip()), 0.0


def compare_metric(
    key: str,
    expected_str: str,
    reproduced: Optional[str],
    tol: float,
    allow_missing: bool = False,
) -> str:
    """Returns PASS/FAIL/WARN/SKIP."""
    if reproduced is None:
        if allow_missing:
            return SKIP
        return FAIL

    exp_mean, exp_std = parse_mean_std(str(expected_str))

    if isinstance(reproduced, str) and "±" in reproduced:
        rep_mean, rep_std = parse_mean_std(reproduced)
    else:
        rep_mean = float(reproduced)
        rep_std = 0.0

    diff = abs(rep_mean - exp_mean)
    # tolerance: paper tol OR 2*reported_std (whichever is larger)
    effective_tol = max(tol, 2 * exp_std)
    if diff <= effective_tol:
        return PASS
    elif diff <= 2 * effective_tol:
        return WARN
    return FAIL


def compare_table(
    title: str,
    expected: dict,
    reproduced: Optional[dict],
    tolerances: Dict[str, float],
    allow_missing: bool = False,
) -> Dict[str, str]:
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")
    print(f"  {'Metric':<35} {'Expected':>14} {'Reproduced':>16} {'Status':>8}")
    print(f"  {'-'*35} {'-'*14} {'-'*16} {'-'*8}")

    statuses = {}
    for key, exp_val in expected.items():
        if isinstance(exp_val, dict):
            continue
        rep_val = reproduced.get(key) if reproduced else None
        tol_key = next((k for k in tolerances if k in key), "default")
        tol = tolerances.get(tol_key, tolerances.get("default", 0.01))

        status = compare_metric(key, exp_val, rep_val, tol, allow_missing)
        statuses[key] = status

        rep_str = str(rep_val) if rep_val is not None else "NOT FOUND"
        print(f"  {key:<35} {str(exp_val):>14} {rep_str:>16} {status:>8}")

    return statuses


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected", default="results/expected")
    parser.add_argument("--reproduced", default="results/reproduced")
    parser.add_argument("--tolerance_auc", type=float, default=0.005)
    parser.add_argument("--tolerance_acc", type=float, default=0.010)
    parser.add_argument("--tolerance_ece", type=float, default=0.5)
    args = parser.parse_args()

    tolerances = {
        "auc": args.tolerance_auc,
        "accuracy": args.tolerance_acc,
        "ece": args.tolerance_ece,
        "mce": args.tolerance_ece,
        "brier": args.tolerance_acc,
        "f1": args.tolerance_acc,
        "sensitivity": args.tolerance_acc,
        "specificity": args.tolerance_acc,
        "ppv": args.tolerance_acc,
        "npv": args.tolerance_acc,
        "mcc": args.tolerance_acc,
        "default": 0.01,
    }

    expected_dir = Path(args.expected)
    reproduced_dir = Path(args.reproduced)

    # Map table number to file names
    tables = {
        "Table 3 – Main model (internal)": ("table3_main_model.json", "table3_main_model.json"),
        "Table 6 – Ablation (architecture)": ("table6_ablation.json", "table6_ablation_architecture.json"),
        "Table 7 – Ablation (fusion)": ("table7_fusion.json", "table7_ablation_fusion.json"),
        "Table 9 – Calibration": ("table9_calibration.json", "table9_calibration.json"),
        "Table 10 – Public datasets": ("table10_public.json", "table10_public.json"),
        "Table 11 – MC uncertainty": ("table11_mc.json", "table11_mc_uncertainty.json"),
    }

    all_statuses = []

    for title, (exp_file, rep_file) in tables.items():
        exp_path = expected_dir / exp_file
        rep_path = reproduced_dir / rep_file

        if not exp_path.exists():
            print(f"\n{SKIP} {title}: expected file not found ({exp_path})")
            continue

        expected = load_json(str(exp_path))
        reproduced = load_json(str(rep_path))

        if reproduced is None:
            print(f"\n{FAIL} {title}: reproduced file not found. Run evaluate_all.py first.")
            all_statuses.append("FAIL")
            continue

        # Handle nested structure (aggregated key)
        if "aggregated" in reproduced:
            reproduced = reproduced["aggregated"]
        if "aggregated" in expected:
            expected_data = expected["aggregated"]
        else:
            expected_data = expected

        # Flatten if expected has experiment-level nesting
        if all(isinstance(v, dict) for v in expected_data.values()):
            for exp_name, exp_metrics in expected_data.items():
                rep_metrics = reproduced.get(exp_name)
                statuses = compare_table(
                    f"{title} / {exp_name}",
                    exp_metrics, rep_metrics, tolerances, allow_missing=True
                )
                all_statuses.extend(statuses.values())
        else:
            statuses = compare_table(title, expected_data, reproduced, tolerances)
            all_statuses.extend(statuses.values())

    # Summary
    n_pass = sum(1 for s in all_statuses if "PASS" in str(s))
    n_warn = sum(1 for s in all_statuses if "WARN" in str(s))
    n_fail = sum(1 for s in all_statuses if "FAIL" in str(s))
    n_skip = sum(1 for s in all_statuses if "SKIP" in str(s))
    total = len(all_statuses)

    print(f"\n{'='*70}")
    print(f"  SUMMARY")
    print(f"{'='*70}")
    print(f"  PASS: {n_pass}/{total}  |  WARN: {n_warn}  |  FAIL: {n_fail}  |  SKIP: {n_skip}")
    print(f"\n  Tolerance: AUC ±{args.tolerance_auc}, Accuracy ±{args.tolerance_acc}, ECE ±{args.tolerance_ece} pp")
    print(f"  WARN = within 2x tolerance; FAIL = exceeds 2x tolerance")
    if n_fail > 0:
        print(f"\n  {FAIL}: {n_fail} metric(s) outside tolerance. Check reproduce steps in README.")
    elif n_warn > 0:
        print(f"\n  {WARN}: Results within 2x tolerance (acceptable variation across hardware/seeds).")
    else:
        print(f"\n  {PASS}: All reproduced results match paper values within tolerance.")


if __name__ == "__main__":
    main()
